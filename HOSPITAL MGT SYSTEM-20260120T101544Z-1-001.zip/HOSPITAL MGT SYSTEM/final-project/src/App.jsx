import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./pages/Login";
import AdminDashboard from "./pages/Admin/AdminDashboard";
import UserManagement from "./pages/Admin/AdminUserManagement"; // Assuming you have a UserManagement page'
import ResourceManagement from "./pages/Admin/AdminResourceManagement";
import AdminBilling from "./pages/Admin/AdminBilling"; // Assuming you have a Billing page
import AdminSettings from "./pages/Admin/AdminSettings"; // Assuming you have a Settings page
import AppointmentBooking from "./pages/Patient/AppointmentBooking";
import AdminAppointmentManagement from "./pages/Admin/AdminAppointmentManagement"; // Assuming you have an Appointment Management page
import AppointmentConfirmation from "./pages/Patient/AppointmentConfirmation";
import NotificationsPage from './pages/Admin/AdminNotificationsPage';
import DoctorDashboard from './pages/Doctor/DoctorDashboard'; // Importing the Doctor Dashboard page
import DoctorPatientManagement from "./pages/Doctor/DoctorPatientManagement";
import DoctorAppointmentPage from "./pages/Doctor/DoctorAppointmentPage";
import DoctorBillingPage from "./pages/Doctor/DoctorBilling"; // Importing the Doctor Billing page
import DoctorPrescriptionPage from "./pages/Doctor/DoctorPrescription";
import DoctorSettingsPage from "./pages/Doctor/DoctorSettings";
import PharmacistDashboard from "./pages/Pharmacist/PharmacistDashboard";
import PharmacistInventory from "./pages/Pharmacist/PharmacistInventory"; // Importing the Pharmacist Inventory page
import PharmacistPrescriptionHistory from "./pages/Pharmacist/PharmacistPrescriptionHistory"; // Importing the Pharmacist Prescription History page 
import PharmacistBilling from "./pages/Pharmacist/PharmacistBilling"; // Importing the Pharmacist Billing page
import PharmacistPatientInfo from "./pages/Pharmacist/PharmacistPatientInfo"; // Importing the Pharmacist Patient Info page
import PharmacistSettings from "./pages/Pharmacist/PharmacistSettings"; // Importing the Pharmacist Settings page
import ReceptionistDashboard from "./pages/Receptionist/ReceptionistDashboard"; // Importing the Receptionist Dashboard page
import ReceptionistSettings from "./pages/Receptionist/ReceptionistSettings"; // Importing the Receptionist Settings page
import ReceptionistBilling from "./pages/Receptionist/ReceptionistBilling"; // Importing the Receptionist Billing page
import ReceptionistPatientManagement from "./pages/Receptionist/ReceptionistPatientManagement"; // Importing the Receptionist Patient Management page
import DoctorNotificationsPage from "./pages/Doctor/DoctorNotificationsPage";
import PharmacistNotificationsPage from "./pages/Pharmacist/PharmacistNotificationsPage"; // Importing the Pharmacist Notifications page
import ReceptionistNotificationsPage from "./pages/Receptionist/ReceptionistNotificationsPage"; // Importing the Receptionist Notifications page
import { LogIn } from "lucide-react";
import HospitalWebsiteBooking from "./pages/Patient/HospitalWebsiteBooking";

function App() {
  return (
    <Router>
      {/* <Navigation /> */}

      <Routes>
        {/* Default route redirects to /login */}
        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* Login route */}
        <Route path="/login" element={<LoginPage />} />
        {/* Admin Dashboard route */}
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        {/* User Management route */}
        <Route path="/users" element={<UserManagement />} />
        {/* Resource Management route */}
        <Route path="/resources" element={<ResourceManagement />} />
        {/* Billing route */}
        <Route path="/billing" element={<AdminBilling />} />
        {/* Settings route */}
        <Route path="/settings" element={<AdminSettings />} />
        {/* Appointment management route */}
        <Route path="/appointments" element={<AdminAppointmentManagement />} />
      
        <Route path="/admin/notifications" element={<NotificationsPage />} />
        <Route path="/doctor-dashboard" element={<DoctorDashboard />} />
        <Route path="/doctor-patientmanagement" element={<DoctorPatientManagement />} />
        <Route path="/doctor-appointmentpage" element={<DoctorAppointmentPage />} />
        <Route path="/doctor-billing" element={<DoctorBillingPage />} />
        <Route path="/doctor-prescription" element={<DoctorPrescriptionPage />} />
        <Route path="/doctor-settings" element={<DoctorSettingsPage />} />
        {/* Pharmacist Dashboard route */}
        <Route path="/pharmacist-dashboard" element={<PharmacistDashboard />} />
        {/* Pharmacist Inventory route */}
        <Route path="/pharmacist-inventory" element={<PharmacistInventory />} />
        {/* Pharmacist Prescription History route */}
        <Route path="/pharmacist-prescrptionhistory" element={<PharmacistPrescriptionHistory />} />
        {/* Pharmacist Billing route */}
        <Route path="/pharmacist-billing" element={<PharmacistBilling />} />
        {/* Pharmacist Patient Information route */}
        <Route path="/pharmacist-patientinfo" element={<PharmacistPatientInfo/>} />
        {/* Pharmacist Settings route */}
        <Route path="/pharmacist-settings" element={<PharmacistSettings />} />
        
        {/* Appointment Booking route */}
        <Route path="/appointment-booking" element={<AppointmentBooking />} />
        {/* Appointment Confirmation route */}
        <Route path="/appointment-confirmation" element={<AppointmentConfirmation />} />
        {/* Receptionist Dashboard route */}
        <Route path="/receptionist-dashboard" element={<ReceptionistDashboard />} />
        {/* Receptionist Settings route */}
        <Route path="/receptionist-settings" element={<ReceptionistSettings />} />
        {/* Receptionist Billing route */}
        <Route path="/receptionist-billing" element={<ReceptionistBilling />} />
        {/* Receptionist Patient Management route */}
        <Route path="/receptionist-patient-management" element={<ReceptionistPatientManagement />} />
         {/* <Route path="/doctor/notifications" element={<NotificationsPage />} />
         */}
        {/* Doctor Notifications route */}
        <Route path="/doctor/notifications" element={<DoctorNotificationsPage />} />
        {/* Pharmacist Notifications route */}
        <Route path="/pharmacist/notifications" element={<PharmacistNotificationsPage />} />
        {/* Receptionist Notifications route */}
        <Route path="/receptionist/notifications" element={<ReceptionistNotificationsPage />} />
        {/* Hospital Website Booking route */}
        <Route path="/hospital-website-booking" element={<HospitalWebsiteBooking />} />
      </Routes>
      
      {/* <AppointmentBooking />;
      <AppointmentConfirmation />;
      <LogIn/>; */}
      
    </Router>
  );
}




export default App;
