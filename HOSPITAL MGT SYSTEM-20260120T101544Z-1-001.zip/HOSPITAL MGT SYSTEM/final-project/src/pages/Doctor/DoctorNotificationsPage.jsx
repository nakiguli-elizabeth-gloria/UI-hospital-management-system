// src/pages/Doctor/DoctorNotificationsPage.jsx

import React, { useState } from 'react';
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopbar from '../../components/DoctorTopbar';
import '../../assets/css/Doctor/DoctorNotificationsPage.css';

const sampleNotifications = [
  {
    id: 1,
    title: 'New Appointment',
    message: 'You have a new appointment with John Doe at 10:00 AM.',
    date: '2025-07-17',
  },
  {
    id: 1,
    title: 'New Appointment',
    message: 'You have a new appointment with John Doe at 10:00 AM.',
    date: '2025-07-17',
  },
  {
    id: 1,
    title: 'New Appointment',
    message: 'You have a new appointment with John Doe at 10:00 AM.',
    date: '2025-07-17',
  },
  {
    id: 2,
    title: 'Lab Results Ready',
    message: 'Lab results for patient Jane Smith are ready for review.',
    date: '2025-07-16',
  },
  {
    id: 3,
    title: 'Message from Nurse',
    message: 'Nurse Anita: Patient in Room 203 needs immediate attention.',
    date: '2025-07-15',
  },
];

const DoctorNotificationsPage = () => {
  const [notifications] = useState(sampleNotifications);

  return (
    <div className="doctor-notifications-wrapper">
      <DoctorSidebar />

      <main className="doctor-notifications-main">
        <DoctorTopbar title="Notifications" />

        <section className="notification-page">
          {/* <h2 className="notification-page-title">Notifications</h2> */}

          <div className="notification-card">
            <div className="notifications-list">
              {notifications.length === 0 ? (
                <p className="no-results">No new notifications.</p>
              ) : (
                notifications.map((notification) => (
                  <article
                    key={notification.id}
                    className="notification-item"
                    role="region"
                    aria-labelledby={`notification-title-${notification.id}`}
                  >
                    <header className="notification-header">
                      <h3 id={`notification-title-${notification.id}`} className="notification-title">
                        {notification.title}
                      </h3>
                      <time className="notification-date" dateTime={notification.date}>
                        {notification.date}
                      </time>
                    </header>
                    <p className="notification-message">{notification.message}</p>
                  </article>
                ))
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default DoctorNotificationsPage;
