import React, { useState } from 'react';
import '../../assets/css/Doctor/DoctorSettings.css';
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopBar from '../../components/DoctorTopbar';

const DoctorSettingsPage = () => {
  const [doctorName, setDoctorName] = useState('Dr. Jane Doe');
  const [email, setEmail] = useState('dr.jane@example.com');
  const [phone, setPhone] = useState('0700123456');
  const [specialization, setSpecialization] = useState('Cardiologist');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const specializations = [
    'Cardiologist',
    'Dermatologist',
    'Neurologist',
    'Pediatrician',
    'General Practitioner',
    'Orthopedic Surgeon',
    'Psychiatrist',
    'Radiologist',
    'Other',
  ];

  const handleProfileUpdate = () => {
    // TODO: Add API call
    alert('Profile updated successfully!');
  };

  const handlePasswordChange = () => {
    if (newPassword !== confirmPassword) {
      alert('New password and confirmation do not match!');
    } else {
      // TODO: Add API call
      alert('Password changed successfully!');
    }
  };

  return (
    <div className="settings-management">
      <DoctorSidebar />
      <div className="main-content">
        <DoctorTopBar title="Settings" />

        <div className="settings-wrapper">
          {/* Profile Update Section */}
          <div className="settings-section">
            <h3 className="section-title">Doctor Profile</h3>
            <div className="input-field">
              <label>Full Name</label>
              <input
                type="text"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <div className="input-field specialization-field">
              <label>Specialization</label>
              <select
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
              >
                {specializations.map((spec) => (
                  <option key={spec} value={spec}>
                    {spec}
                  </option>
                ))}
              </select>
            </div>
            <button className="update-button" onClick={handleProfileUpdate}>
              Update Profile
            </button>
          </div>

          {/* Password Change Section */}
          <div className="settings-section">
            <h3 className="section-title">Change Password</h3>
            <div className="input-field">
              <label>Current Password</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>New Password</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>
            <button className="update-button" onClick={handlePasswordChange}>
              Change Password
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorSettingsPage;
