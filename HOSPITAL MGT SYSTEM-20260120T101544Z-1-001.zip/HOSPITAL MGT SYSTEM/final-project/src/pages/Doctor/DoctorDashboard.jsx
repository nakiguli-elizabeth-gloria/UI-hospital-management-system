import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Step 1
import '../../assets/css/Doctor/DoctorDashboard.css';
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopBar from '../../components/DoctorTopbar';
import {
  CalendarCheck2,
  FileText,
  UserCheck,
  Clipboard,
  ListChecks,
  Users,
  Settings,
  AlarmClock,
} from 'lucide-react';

const initialAppointments = [
  { id: 1, patient: 'John Doe', date: '2025-07-15', time: '10:00 AM', reason: 'Follow-up', status: 'Scheduled' },
  { id: 2, patient: 'Jane Smith', date: '2025-07-15', time: '11:00 AM', reason: 'Consultation', status: 'Scheduled' },
  { id: 3, patient: 'Alice Brown', date: '2025-07-15', time: '1:00 PM', reason: 'Checkup', status: 'Scheduled' },
  { id: 4, patient: 'Mark Twin', date: '2025-07-15', time: '2:00 PM', reason: 'Flu symptoms', status: 'Done' },
  { id: 5, patient: 'Elisa White', date: '2025-07-15', time: '3:00 PM', reason: 'Routine Check', status: 'Scheduled' },
  { id: 6, patient: 'Harry Stone', date: '2025-07-15', time: '4:00 PM', reason: 'Allergy', status: 'Done' },
];

const DoctorDashboard = () => {
  const [appointments, setAppointments] = useState(initialAppointments);
  const navigate = useNavigate(); // Step 2

  const toggleAppointmentStatus = (id) => {
    setAppointments((prev) => {
      // Map and toggle status
      const updated = prev.map((appt) =>
        appt.id === id
          ? { ...appt, status: appt.status === 'Done' ? 'Scheduled' : 'Done' }
          : appt
      );
      // Sort: Scheduled first, Done last
      updated.sort((a, b) => {
        if (a.status === b.status) return 0;
        return a.status === 'Scheduled' ? -1 : 1;
      });
      return [...updated];
    });
  };

  const totalAppointments = appointments.length;
  const completedAppointments = appointments.filter((a) => a.status === 'Done').length;
  const pendingAppointments = appointments.filter((a) => a.status !== 'Done').length;
  const activePatients = [...new Set(appointments.map((a) => a.patient))].length;
  const topAppointments = appointments;

  return (
    <div className="doctor-dashboard">
      {/* Sidebar */}
      <aside className="sidebar">
        <DoctorSidebar />
      </aside>

      {/* Main content */}
      <main className="main-content">
        <DoctorTopBar />

        <section className="dashboard-content">
          <div className="card-grid">
            <div className="dashboard-card">
              <ListChecks className="dashboard-icon" />
              <h3>Total Appointments</h3>
              <p>{totalAppointments}</p>
            </div>

            <div className="dashboard-card">
              <Users className="dashboard-icon" />
              <h3>Active Patients</h3>
              <p>{activePatients}</p>
            </div>

            {/* Optional filler cards
            <div className="dashboard-card">
              <CalendarCheck2 className="dashboard-icon" />
              <h3>Completed Appointments</h3>
              <p>{completedAppointments}</p>
            </div>

            <div className="dashboard-card">
              <AlarmClock className="dashboard-icon" />
              <h3>Pending Appointments</h3>
              <p>{pendingAppointments}</p>
            </div> */}

            {/* Linked Cards */}
            <div className="dashboard-card clickable" onClick={() => navigate('/doctor-patientmanagement')}>
              <UserCheck className="dashboard-icon" />
              <h3>Manage Patients</h3>
              <p>Access and update patient profiles.</p>
            </div>

            <div className="dashboard-card clickable" onClick={() => navigate('/doctor-appointmentpage')}>
              <CalendarCheck2 className="dashboard-icon" />
              <h3>Manage Appointments</h3>
              <p>Review your upcoming appointments.</p>
            </div>

            {/* <div className="dashboard-card clickable" onClick={() => navigate('/doctor-billing')}>
              <FileText className="dashboard-icon" />
              <h3>Billing</h3>
              <p>Log patient diagnoses and observations.</p>
            </div> */}

            <div className="dashboard-card clickable" onClick={() => navigate('/doctor-settings')}>
              <Settings className="dashboard-icon" />
              <h3>Settings</h3>
              <p>View patient medical records.</p>
            </div>
          </div>

          {/* Appointments Table */}
          <section className="appointments-section">
            <h3>Today's Appointments</h3>
            <div className="appointments-table-wrapper no-scroll">
              <table className="appointments-table">
                <thead>
                  <tr>
                    <th>Patient</th>
                    <th>Time</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Done</th>
                  </tr>
                </thead>
                <tbody>
                  {topAppointments.map((appt) => (
                    <tr key={appt.id}>
                      <td>{appt.patient}</td>
                      <td>{appt.time}</td>
                      <td>{appt.reason}</td>
                      <td>{appt.status}</td>
                      <td>
                        <input
                          type="checkbox"
                          checked={appt.status === 'Done'}
                          onChange={() => toggleAppointmentStatus(appt.id)}
                          title="Mark appointment done"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </section>
      </main>
    </div>
  );
};

export default DoctorDashboard;
