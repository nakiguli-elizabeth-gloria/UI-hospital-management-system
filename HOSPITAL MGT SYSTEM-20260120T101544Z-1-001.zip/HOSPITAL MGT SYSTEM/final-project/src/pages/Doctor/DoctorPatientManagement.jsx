import React, { useState } from 'react';
import '../../assets/css/Doctor/DoctorPatientManagement.css';
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopbar from '../../components/DoctorTopbar';

const DoctorPatientManagement = () => {
  const initialPatients = [
    {
      id: 1,
      name: 'John Doe',
      age: 45,
      condition: 'Diabetes',
      lastVisit: '2023-07-10',
      medicalHistory: [
        { date: '2023-07-10', diagnosis: 'Type 2 Diabetes', notes: 'Patient showing good control' },
        { date: '2022-12-01', diagnosis: 'High Blood Pressure', notes: 'Prescribed medication' },
      ],
      prescriptions: [
        { date: '2023-07-10', medicine: 'Metformin', dosage: '500mg', instructions: 'Twice daily' },
      ],
      gender: 'Male',
      address: '123 Main St',
      phone: '555-1234',
    },
    // ... other patients ...
  ];

  const [patients, setPatients] = useState(initialPatients);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showAddPrescriptionModal, setShowAddPrescriptionModal] = useState(false);
  const [showEditPatientModal, setShowEditPatientModal] = useState(false);
  const [showAddPatientModal, setShowAddPatientModal] = useState(false);

  const [newPrescription, setNewPrescription] = useState({
    medicine: '',
    dosage: '',
    instructions: '',
  });

  const [editPatientData, setEditPatientData] = useState({
    id: null,
    name: '',
    age: '',
    gender: '',
    address: '',
    phone: '',
    condition: '',
    lastVisit: '',
  });

  const [newPatientData, setNewPatientData] = useState({
    name: '',
    age: '',
    gender: '',
    address: '',
    phone: '',
    condition: '',
    lastVisit: '',
  });

  const filteredPatients = patients.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handlers for Prescription modal
  const handlePrescriptionChange = (e) => {
    const { name, value } = e.target;
    setNewPrescription((prev) => ({ ...prev, [name]: value }));
  };

  const handleSavePrescription = () => {
    if (!newPrescription.medicine || !newPrescription.dosage || !newPrescription.instructions) {
      alert('Please fill all prescription fields.');
      return;
    }

    setPatients((prevPatients) =>
      prevPatients.map((patient) => {
        if (patient.id === selectedPatient.id) {
          const updatedPrescriptions = [
            ...(patient.prescriptions || []),
            {
              date: new Date().toISOString().slice(0, 10),
              ...newPrescription,
            },
          ];
          return { ...patient, prescriptions: updatedPrescriptions };
        }
        return patient;
      })
    );

    alert(`Prescription added for ${selectedPatient.name}`);
    setNewPrescription({ medicine: '', dosage: '', instructions: '' });
    setShowAddPrescriptionModal(false);
    setSelectedPatient(null);
  };

  const closeAddPrescriptionModal = () => {
    setShowAddPrescriptionModal(false);
    setSelectedPatient(null);
  };

  // Handlers for Edit Patient modal
  const openEditPatientModal = (patient) => {
    setEditPatientData({
      id: patient.id,
      name: patient.name,
      age: patient.age,
      gender: patient.gender || '',
      address: patient.address || '',
      phone: patient.phone || '',
      condition: patient.condition,
      lastVisit: patient.lastVisit,
    });
    setShowEditPatientModal(true);
  };

  const handleEditPatientChange = (e) => {
    const { name, value } = e.target;
    setEditPatientData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveEditedPatient = () => {
    if (
      !editPatientData.name ||
      !editPatientData.age ||
      !editPatientData.gender ||
      !editPatientData.address ||
      !editPatientData.phone ||
      !editPatientData.condition ||
      !editPatientData.lastVisit
    ) {
      alert('Please fill all patient fields.');
      return;
    }

    setPatients((prevPatients) =>
      prevPatients.map((patient) =>
        patient.id === editPatientData.id
          ? { ...patient, ...editPatientData, age: Number(editPatientData.age) }
          : patient
      )
    );

    alert(`Patient ${editPatientData.name} updated.`);
    setShowEditPatientModal(false);
    setEditPatientData({
      id: null,
      name: '',
      age: '',
      gender: '',
      address: '',
      phone: '',
      condition: '',
      lastVisit: '',
    });
  };

  const closeEditPatientModal = () => {
    setShowEditPatientModal(false);
  };

  // Handlers for Add Patient modal
  const openAddPatientModal = () => {
    setNewPatientData({
      name: '',
      age: '',
      gender: '',
      address: '',
      phone: '',
      condition: '',
      lastVisit: new Date().toISOString().slice(0, 10),
    });
    setShowAddPatientModal(true);
  };

  const handleNewPatientChange = (e) => {
    const { name, value } = e.target;
    setNewPatientData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSaveNewPatient = () => {
    if (
      !newPatientData.name ||
      !newPatientData.age ||
      !newPatientData.gender ||
      !newPatientData.address ||
      !newPatientData.phone ||
      !newPatientData.condition ||
      !newPatientData.lastVisit
    ) {
      alert('Please fill all patient fields.');
      return;
    }

    const newId = patients.length ? Math.max(...patients.map((p) => p.id)) + 1 : 1;
    const newPatient = {
      id: newId,
      name: newPatientData.name,
      age: Number(newPatientData.age),
      gender: newPatientData.gender,
      address: newPatientData.address,
      phone: newPatientData.phone,
      condition: newPatientData.condition,
      lastVisit: newPatientData.lastVisit,
      medicalHistory: [],
      prescriptions: [],
    };

    setPatients((prevPatients) => [newPatient, ...prevPatients]);

    alert(`Patient ${newPatient.name} added.`);
    setShowAddPatientModal(false);
  };

  const closeAddPatientModal = () => {
    setShowAddPatientModal(false);
  };

  // DELETE PATIENT FUNCTION
  const handleDeletePatient = (id) => {
    if (window.confirm('Are you sure you want to delete this patient?')) {
      setPatients((prevPatients) => prevPatients.filter((patient) => patient.id !== id));
      if (selectedPatient && selectedPatient.id === id) {
        setSelectedPatient(null);
        setShowAddPrescriptionModal(false);
      }
    }
  };

  // Close medical history modal
  const closeMedicalHistoryModal = () => {
    setSelectedPatient(null);
  };

  return (
    <div>
      <DoctorSidebar />
      <DoctorTopbar />
      <div className="patient-management-container">
        <div className="top-controls">
          <input
            type="text"
            placeholder="Search patient by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <button className="add-button" onClick={openAddPatientModal}>
            + Add Patient
          </button>
        </div>

        {filteredPatients.length > 0 ? (
          <table className="patient-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Age</th>
                <th>Condition</th>
                <th>Last Visit</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPatients.map((patient) => (
                <tr key={patient.id}>
                  <td>{patient.name}</td>
                  <td>{patient.age}</td>
                  <td>{patient.condition}</td>
                  <td>{patient.lastVisit}</td>
                  <td>
                    <button
                      className="edit-button"
                      onClick={() => openEditPatientModal(patient)}
                    >
                      Edit
                    </button>
                    <button
                      className="secondary-button"
                      onClick={() => {
                        setSelectedPatient(patient);
                        setShowAddPrescriptionModal(false);
                      }}
                    >
                      View History
                    </button>
                    <button
                      className="secondary-button"
                      onClick={() => {
                        setSelectedPatient(patient);
                        setShowAddPrescriptionModal(true);
                      }}
                    >
                      Add Prescription
                    </button>
                    <button
                      className="delete-button"
                      onClick={() => handleDeletePatient(patient.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="no-data">No patients found.</p>
        )}

        {/* Edit Patient Modal */}
        {showEditPatientModal && (
          <div className="modal-overlay modal-edit-patient" onClick={closeEditPatientModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>Edit Patient</h3>
              <label>Name</label>
              <input
                type="text"
                name="name"
                value={editPatientData.name}
                onChange={handleEditPatientChange}
                placeholder="Patient Name"
              />
              <label>Age</label>
              <input
                type="number"
                name="age"
                value={editPatientData.age}
                onChange={handleEditPatientChange}
                placeholder="Age"
                min="0"
              />

              <label>Gender</label>
              <select
                name="gender"
                value={editPatientData.gender}
                onChange={handleEditPatientChange}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>

              <label>Address</label>
              <input
                type="text"
                name="address"
                value={editPatientData.address}
                onChange={handleEditPatientChange}
                placeholder="Address"
              />

              <label>Phone Number</label>
              <input
                type="tel"
                name="phone"
                value={editPatientData.phone}
                onChange={handleEditPatientChange}
                placeholder="Phone Number"
              />

              <label>Condition</label>
              <input
                type="text"
                name="condition"
                value={editPatientData.condition}
                onChange={handleEditPatientChange}
                placeholder="Condition"
              />
              <label>Last Visit</label>
              <input
                type="date"
                name="lastVisit"
                value={editPatientData.lastVisit}
                onChange={handleEditPatientChange}
              />

              <div style={{ marginTop: '15px' }}>
                <button onClick={handleSaveEditedPatient} className="save-button">
                  Save Changes
                </button>
                <button
                  onClick={closeEditPatientModal}
                  className="cancel-button"
                  style={{ marginLeft: '10px' }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Add Patient Modal */}
        {showAddPatientModal && (
          <div className="modal-overlay modal-add-patient" onClick={closeAddPatientModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>Add New Patient</h3>
              <label>Name</label>
              <input
                type="text"
                name="name"
                value={newPatientData.name}
                onChange={handleNewPatientChange}
                placeholder="Patient Name"
              />
              <label>Age</label>
              <input
                type="number"
                name="age"
                value={newPatientData.age}
                onChange={handleNewPatientChange}
                placeholder="Age"
                min="0"
              />

              <label>Gender</label>
              <select
                name="gender"
                value={newPatientData.gender}
                onChange={handleNewPatientChange}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>

              <label>Address</label>
              <input
                type="text"
                name="address"
                value={newPatientData.address}
                onChange={handleNewPatientChange}
                placeholder="Address"
              />

              <label>Phone Number</label>
              <input
                type="tel"
                name="phone"
                value={newPatientData.phone}
                onChange={handleNewPatientChange}
                placeholder="Phone Number"
              />

              <label>Condition</label>
              <input
                type="text"
                name="condition"
                value={newPatientData.condition}
                onChange={handleNewPatientChange}
                placeholder="Condition"
              />
              <label>Last Visit</label>
              <input
                type="date"
                name="lastVisit"
                value={newPatientData.lastVisit}
                onChange={handleNewPatientChange}
              />

              <div style={{ marginTop: '15px' }}>
                <button onClick={handleSaveNewPatient} className="save-button">
                  Add Patient
                </button>
                <button
                  onClick={closeAddPatientModal}
                  className="cancel-button"
                  style={{ marginLeft: '10px' }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Medical History Modal */}
        {selectedPatient && !showAddPrescriptionModal && !showEditPatientModal && (
          <div className="modal-overlay modal-history" onClick={closeMedicalHistoryModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>{selectedPatient.name}'s Medical History</h3>

              <section className="history-section">
                <h4>Medical History</h4>
                {selectedPatient.medicalHistory.length > 0 ? (
                  selectedPatient.medicalHistory.map((record, index) => (
                    <div key={index} className="history-record">
                      <div><strong>Date:</strong> {record.date}</div>
                      <div><strong>Diagnosis:</strong> {record.diagnosis}</div>
                      <div><strong>Notes:</strong> {record.notes}</div>
                    </div>
                  ))
                ) : (
                  <p>No medical history records.</p>
                )}
              </section>

              <section className="history-section">
                <h4>Prescriptions</h4>
                {selectedPatient.prescriptions && selectedPatient.prescriptions.length > 0 ? (
                  selectedPatient.prescriptions.map((presc, idx) => (
                    <div key={idx} className="history-record">
                      <div><strong>Date:</strong> {presc.date}</div>
                      <div><strong>Medicine:</strong> {presc.medicine}</div>
                      <div><strong>Dosage:</strong> {presc.dosage}</div>
                      <div><strong>Instructions:</strong> {presc.instructions}</div>
                    </div>
                  ))
                ) : (
                  <p>No prescriptions available.</p>
                )}
              </section>

              <button className="cancel-button" onClick={closeMedicalHistoryModal}>
                Close
              </button>
            </div>
          </div>
        )}

        {/* Add Prescription Modal */}
        {showAddPrescriptionModal && selectedPatient && (
          <div className="modal-overlay modal-add-prescription" onClick={closeAddPrescriptionModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>Add Prescription for {selectedPatient.name}</h3>

              <label>Medicine</label>
              <input
                type="text"
                name="medicine"
                value={newPrescription.medicine}
                onChange={handlePrescriptionChange}
                placeholder="Enter medicine"
              />
              <label>Dosage</label>
              <input
                type="text"
                name="dosage"
                value={newPrescription.dosage}
                onChange={handlePrescriptionChange}
                placeholder="Enter dosage"
              />
              <label>Instructions</label>
              <textarea
                name="instructions"
                value={newPrescription.instructions}
                onChange={handlePrescriptionChange}
                placeholder="Enter instructions"
              />

              <div style={{ marginTop: '15px' }}>
                <button onClick={handleSavePrescription} className="save-button">
                  Save Prescription
                </button>
                <button
                  onClick={closeAddPrescriptionModal}
                  className="cancel-button"
                  style={{ marginLeft: '10px' }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorPatientManagement;
