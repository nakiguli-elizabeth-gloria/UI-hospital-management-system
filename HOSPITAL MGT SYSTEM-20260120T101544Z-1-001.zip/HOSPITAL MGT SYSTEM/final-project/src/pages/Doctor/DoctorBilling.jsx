import React, { useState } from 'react';
import '../../assets/css/Doctor/DoctorBilling.css'; // Your CSS file
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopbar from '../../components/DoctorTopbar';

const statusOptions = [
  { value: 'Paid', label: 'Paid', color: '#16a34a' },      // green
  { value: 'Partial', label: 'Partial', color: '#f97316' }, // orange
  { value: 'Pending', label: 'Pending', color: '#dc2626' }, // red
];

const DoctorBillingPage = () => {
  const [billings, setBillings] = useState([
    {
      id: 1,
      patientName: 'John Doe',
      dateOfService: '2025-07-14',
      consultationFee: 200,
      amountPaid: 150,
      balance: 50,
      status: 'Partial',
      doctorNotes: 'Follow-up required in 2 weeks.',
    },
    {
      id: 2,
      patientName: 'Jane Smith',
      dateOfService: '2025-07-12',
      consultationFee: 300,
      amountPaid: 300,
      balance: 0,
      status: 'Paid',
      doctorNotes: 'Routine check-up completed.',
    },
    {
      id: 3,
      patientName: 'Emily Clark',
      dateOfService: '2025-07-10',
      consultationFee: 450,
      amountPaid: 100,
      balance: 350,
      status: 'Pending',
      doctorNotes: 'Patient advised for lab tests.',
    },
    // Add more entries as needed
  ]);

  const [selectedBilling, setSelectedBilling] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter billings by patientName based on search query (case-insensitive)
  const filteredBillings = billings.filter((billing) =>
    billing.patientName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Update status handler
  const handleStatusChange = (id, newStatus) => {
    setBillings((prev) =>
      prev.map((billing) =>
        billing.id === id ? { ...billing, status: newStatus } : billing
      )
    );
  };

  // Helper to get color by status value
  const getStatusColor = (status) => {
    const option = statusOptions.find((opt) => opt.value === status);
    return option ? option.color : '#000';
  };

  return (
    <div>
      <DoctorSidebar />
      <DoctorTopbar />
      <div
        className="billing-management-container"
        style={{
          padding: '80px 30px 30px 30px',
          marginLeft: '220px',
          minHeight: '100vh',
          backgroundColor: '#f4f6f8',
        }}
      >
        {/* Search bar */}
        <input
          type="text"
          placeholder="Search by patient name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{
            marginBottom: '20px',
            padding: '10px',
            width: '100%',
            maxWidth: '400px',
            fontSize: '14px',
            borderRadius: '6px',
            border: '1px solid #ccc',
          }}
        />

        {filteredBillings.length > 0 ? (
          <table
            className="billing-table"
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              backgroundColor: 'white',
              boxShadow: '0 0 10px rgba(0,0,0,0.1)',
              fontSize: '14px',
            }}
          >
            <thead>
              <tr style={{ backgroundColor: '#1e3a8a', color: 'white' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Patient Name
                </th>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Date of Service
                </th>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Consultation Fee
                </th>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Amount Paid
                </th>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Balance
                </th>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Status
                </th>
                <th style={{ padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredBillings.map((billing) => (
                <tr key={billing.id} style={{ borderBottom: '1px solid #ddd' }}>
                  <td style={{ padding: '12px 16px' }}>{billing.patientName}</td>
                  <td style={{ padding: '12px 16px' }}>{billing.dateOfService}</td>
                  <td style={{ padding: '12px 16px' }}>${billing.consultationFee}</td>
                  <td style={{ padding: '12px 16px' }}>${billing.amountPaid}</td>
                  <td style={{ padding: '12px 16px' }}>${billing.balance}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <select
                      value={billing.status}
                      onChange={(e) => handleStatusChange(billing.id, e.target.value)}
                      style={{
                        padding: '6px 10px',
                        borderRadius: '6px',
                        border: '1.5px solid #cbd5e1',
                        fontWeight: '600',
                        color: getStatusColor(billing.status),
                        cursor: 'pointer',
                        appearance: 'none',
                        backgroundColor: 'white',
                        width: '120px',
                      }}
                    >
                      {statusOptions.map((option) => (
                        <option
                          key={option.value}
                          value={option.value}
                          style={{ color: option.color, fontWeight: '600' }}
                        >
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <button
                      className="view-button"
                      style={{
                        backgroundColor: '#1976d2',
                        color: 'white',
                        border: 'none',
                        padding: '6px 12px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                      }}
                      onClick={() => setSelectedBilling(billing)}
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p style={{ textAlign: 'center', padding: '20px', color: '#999' }}>
            No billing records found.
          </p>
        )}

        {/* Billing Details Modal */}
        {selectedBilling && (
          <div
            className="modal-overlay"
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0,0,0,0.4)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 999,
            }}
            onClick={() => setSelectedBilling(null)}
          >
            <div
              className="modal-content"
              style={{
                backgroundColor: 'white',
                padding: '30px 40px',
                borderRadius: '6px',
                width: '100%',
                maxWidth: '500px',
                boxShadow: '0 0 15px rgba(0,0,0,0.2)',
                maxHeight: '80vh',
                overflowY: 'auto',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <h3>Billing Details for {selectedBilling.patientName}</h3>
              <p>
                <strong>Date of Service:</strong> {selectedBilling.dateOfService}
              </p>
              <p>
                <strong>Consultation Fee:</strong> ${selectedBilling.consultationFee}
              </p>
              <p>
                <strong>Amount Paid:</strong> ${selectedBilling.amountPaid}
              </p>
              <p>
                <strong>Balance:</strong> ${selectedBilling.balance}
              </p>
              <p>
                <strong>Status:</strong> {selectedBilling.status}
              </p>
              <p>
                <strong>Doctor's Notes:</strong> {selectedBilling.doctorNotes || 'N/A'}
              </p>

              <button
                style={{
                  marginTop: '20px',
                  backgroundColor: 'red',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '15px',
                }}
                onClick={() => setSelectedBilling(null)}
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorBillingPage;
