import React, { useState } from 'react';
import '../../assets/css/Doctor/DoctorPrescription.css';
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopBar from '../../components/DoctorTopbar';

const mockPatients = [
  { id: 1, name: 'John Doe' },
  { id: 2, name: 'Jane Smith' },
  { id: 3, name: 'Emily Clark' },
];

// Mock medical history data keyed by patient id
const mockMedicalHistory = {
  1: [
    {
      id: 1,
      date: '2025-06-10',
      doctor: 'Dr. Adams',
      prescriptions: [
        { medicine: 'Paracetamol', dosage: '500mg', instructions: 'Twice a day' },
      ],
      notes: 'Patient recovering well.',
    },
    {
      id: 2,
      date: '2025-05-20',
      doctor: 'Dr. Baker',
      prescriptions: [
        { medicine: 'Ibuprofen', dosage: '200mg', instructions: 'Once daily' },
      ],
      notes: 'Follow up in 2 weeks.',
    },
  ],
  2: [
    {
      id: 3,
      date: '2025-07-01',
      doctor: 'Dr. Clark',
      prescriptions: [
        { medicine: 'Amoxicillin', dosage: '250mg', instructions: '3 times a day' },
      ],
      notes: 'Complete full course.',
    },
  ],
  3: [],
};

const DoctorPrescriptionPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState(null);

  // Prescription modal
  const [showPrescribeModal, setShowPrescribeModal] = useState(false);
  const [prescriptionForm, setPrescriptionForm] = useState({
    medicine: '',
    dosage: '',
    instructions: '',
  });
  const [patientPrescriptions, setPatientPrescriptions] = useState([]);

  // History modal
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  // Filter patients by search
  const filteredPatients = mockPatients.filter((p) =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle patient selection (reset forms and modals)
  const handleSelectPatient = (patient) => {
    setSelectedPatient(patient);
    setPatientPrescriptions([]);
    setPrescriptionForm({ medicine: '', dosage: '', instructions: '' });
    setShowPrescribeModal(false);
    setShowHistoryModal(false);
  };

  // Handle prescription form changes
  const handlePrescriptionChange = (e) => {
    const { name, value } = e.target;
    setPrescriptionForm((prev) => ({ ...prev, [name]: value }));
  };

  // Add prescription to current list (unsaved)
  const handleAddPrescription = () => {
    const { medicine, dosage, instructions } = prescriptionForm;
    if (!medicine || !dosage || !instructions) {
      alert('Please fill all prescription fields.');
      return;
    }
    setPatientPrescriptions((prev) => [
      ...prev,
      { id: prev.length + 1, medicine, dosage, instructions },
    ]);
    setPrescriptionForm({ medicine: '', dosage: '', instructions: '' });
  };

  // "Save" prescriptions (mock)
  const handleSavePrescriptions = () => {
    if (patientPrescriptions.length === 0) {
      alert('No prescriptions to save.');
      return;
    }
    alert(`Saved ${patientPrescriptions.length} prescriptions for ${selectedPatient.name}`);
    setPatientPrescriptions([]);
    setShowPrescribeModal(false);
  };

  return (
    <div>
      <DoctorSidebar />
      <DoctorTopBar />
      <div className="appointment-management-container">
        <h2>Doctor's Prescription Portal</h2>

        {/* Search patient */}
        <div className="top-controls">
          <input
            type="text"
            className="search-input"
            placeholder="Search patient..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Patient list */}
        {filteredPatients.length > 0 ? (
          <table className="appointment-table">
            <thead>
              <tr>
                <th>Patient Name</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPatients.map((patient) => (
                <tr
                  key={patient.id}
                  className={selectedPatient?.id === patient.id ? 'selected' : ''}
                  onClick={() => handleSelectPatient(patient)}
                  style={{ cursor: 'pointer' }}
                >
                  <td>{patient.name}</td>
                  <td>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectPatient(patient);
                        setShowHistoryModal(true);
                        setShowPrescribeModal(false);
                      }}
                    >
                      View Medical History
                    </button>{' '}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectPatient(patient);
                        setShowPrescribeModal(true);
                        setShowHistoryModal(false);
                      }}
                    >
                      Prescribe Medicine
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="no-data">No patients found.</p>
        )}

        {/* Prescription Modal */}
        {showPrescribeModal && selectedPatient && (
          <div className="modal-overlay" onClick={() => setShowPrescribeModal(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>Prescribe Medicine for {selectedPatient.name}</h3>

              <label>Medicine</label>
              <input
                type="text"
                name="medicine"
                value={prescriptionForm.medicine}
                onChange={handlePrescriptionChange}
                placeholder="Enter medicine"
              />
              <label>Dosage</label>
              <input
                type="text"
                name="dosage"
                value={prescriptionForm.dosage}
                onChange={handlePrescriptionChange}
                placeholder="Enter dosage"
              />
              <label>Instructions</label>
              <textarea
                name="instructions"
                value={prescriptionForm.instructions}
                onChange={handlePrescriptionChange}
                placeholder="Enter instructions"
              />

              <button onClick={handleAddPrescription} style={{ marginTop: '10px' }}>
                Add Prescription
              </button>

              {patientPrescriptions.length > 0 && (
                <>
                  <h4 style={{ marginTop: '20px' }}>Current Prescriptions to Save:</h4>
                  <div className="prescribed-list">
                    {patientPrescriptions.map((p) => (
                      <div key={p.id} className="prescribed-item">
                        <p><strong>Medicine:</strong> {p.medicine}</p>
                        <p><strong>Dosage:</strong> {p.dosage}</p>
                        <p><strong>Instructions:</strong> {p.instructions}</p>
                      </div>
                    ))}
                  </div>
                  <button onClick={handleSavePrescriptions} style={{ marginTop: '10px' }}>
                    Save Prescriptions
                  </button>
                </>
              )}

              <button
                onClick={() => setShowPrescribeModal(false)}
                style={{ marginTop: '15px', backgroundColor: '#dc3545' }}
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Medical History Modal */}
        {showHistoryModal && selectedPatient && (
          <div className="modal-overlay" onClick={() => setShowHistoryModal(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>Medical History for {selectedPatient.name}</h3>
              {mockMedicalHistory[selectedPatient.id]?.length > 0 ? (
                mockMedicalHistory[selectedPatient.id].map((record) => (
                  <div key={record.id} className="history-record">
                    <p>
                      <strong>Date:</strong> {record.date} | <strong>Doctor:</strong> {record.doctor}
                    </p>
                    <p><strong>Notes:</strong> {record.notes}</p>
                    <h4>Prescriptions:</h4>
                    {record.prescriptions.map((p, idx) => (
                      <div key={idx} className="prescribed-item" style={{ paddingLeft: '15px' }}>
                        <p><strong>Medicine:</strong> {p.medicine}</p>
                        <p><strong>Dosage:</strong> {p.dosage}</p>
                        <p><strong>Instructions:</strong> {p.instructions}</p>
                      </div>
                    ))}
                  </div>
                ))
              ) : (
                <p>No medical history available.</p>
              )}

              <button
                onClick={() => setShowHistoryModal(false)}
                style={{ marginTop: '15px', backgroundColor: '#dc3545' }}
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorPrescriptionPage;
