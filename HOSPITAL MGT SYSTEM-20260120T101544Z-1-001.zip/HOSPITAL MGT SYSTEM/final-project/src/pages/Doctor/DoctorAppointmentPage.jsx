import React, { useState } from 'react';
import '../../assets/css/Doctor/DoctorAppointmentPage.css';
import DoctorSidebar from '../../components/DoctorSidebar';
import DoctorTopbar from '../../components/DoctorTopbar';

const statusColors = {
  Scheduled: '#4caf50',
  Completed: '#2196f3',
  Cancelled: '#f44336',
};

const DAYS_OF_WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const DoctorAppointmentPage = () => {
  const [appointments, setAppointments] = useState([
    { id: 1, patientName: 'John Doe', date: '2023-07-12', time: '10:00', status: 'Scheduled' },
    { id: 2, patientName: 'Jane Smith', date: '2023-07-12', time: '11:00', status: 'Completed' },
    { id: 3, patientName: 'Emily Clark', date: '2023-07-13', time: '09:30', status: 'Scheduled' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ patientName: '', date: '', time: '', status: 'Scheduled' });
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  const filteredAppointments = appointments.filter((appt) => {
    const matchesSearch = appt.patientName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDate = selectedDate ? appt.date === selectedDate : true;
    return matchesSearch && matchesDate;
  });

  const formatDateStr = (year, month, day) => {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const getDaysInMonth = (month, year) => new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (month, year) => new Date(year, month, 1).getDay();

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
    setSelectedDate(null);
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
    setSelectedDate(null);
  };

  const generateCalendarGrid = () => {
    const daysInMonth = getDaysInMonth(currentMonth, currentYear);
    const firstDay = getFirstDayOfMonth(currentMonth, currentYear);
    const grid = [];

    for (let i = 0; i < firstDay; i++) grid.push(null);
    for (let day = 1; day <= daysInMonth; day++) grid.push(day);

    return grid;
  };

  const todayStr = formatDateStr(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());

  const handleEdit = (id) => {
    const appt = appointments.find((a) => a.id === id);
    setFormData(appt);
    setEditingId(id);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this appointment?")) {
      setAppointments(appointments.filter((a) => a.id !== id));
      if (editingId === id) {
        setEditingId(null);
        setShowForm(false);
      }
    }
  };

  const handleSubmit = () => {
    const { patientName, date, time } = formData;
    if (!patientName || !date || !time) {
      return alert('Please fill in all fields.');
    }

    if (editingId) {
      setAppointments(appointments.map((a) => (a.id === editingId ? { ...formData, id: editingId } : a)));
    } else {
      const newId = appointments.length > 0 ? Math.max(...appointments.map(a => a.id)) + 1 : 1;
      setAppointments([{ ...formData, id: newId }, ...appointments]);
    }

    setShowForm(false);
    setEditingId(null);
    setFormData({ patientName: '', date: '', time: '', status: 'Scheduled' });
  };

  return (
    <div>
      <DoctorSidebar />
      <DoctorTopbar />

      <div className="appointment-management-container">
        <div className="top-controls">
          <input
            type="text"
            className="search-input"
            placeholder="Search by patient name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button
            className="add-button"
            onClick={() => {
              setShowForm(true);
              setEditingId(null);
              setFormData({ patientName: '', date: '', time: '', status: 'Scheduled' });
            }}
          >
            + Add Appointment
          </button>
        </div>

        {filteredAppointments.length > 0 ? (
          <table className="appointment-table">
            <thead>
              <tr>
                <th>Patient</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.map((appt) => (
                <tr key={appt.id}>
                  <td>{appt.patientName}</td>
                  <td>{appt.date}</td>
                  <td>{appt.time}</td>
                  <td>
                    <span style={{ color: statusColors[appt.status], fontWeight: '600' }}>
                      {appt.status}
                    </span>
                  </td>
                  <td>
                    <button className="edit-button" onClick={() => handleEdit(appt.id)}>Edit</button>
                    <button className="delete-button" onClick={() => handleDelete(appt.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="no-data">No appointments found.</p>
        )}

        {selectedDate && (
          <button className="clear-filter-button" onClick={() => setSelectedDate(null)}>
            Clear Date Filter
          </button>
        )}

        <section className="calendar-container" style={{ marginTop: '40px' }}>
          <div className="calendar-header" style={{ display: 'flex', justifyContent: 'space-between' }}>
            <button onClick={prevMonth}>&lt; Prev</button>
            <span style={{ fontWeight: 'bold' }}>
              {new Date(currentYear, currentMonth).toLocaleString('default', {
                month: 'long',
                year: 'numeric',
              })}
            </span>
            <button onClick={nextMonth}>Next &gt;</button>
          </div>

          <div
            className="calendar-grid"
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(7, 1fr)',
              gap: '5px',
              marginTop: '10px',
            }}
          >
            {DAYS_OF_WEEK.map((day) => (
              <div key={day} style={{ fontWeight: 'bold', textAlign: 'center' }}>
                {day}
              </div>
            ))}
            {generateCalendarGrid().map((day, idx) => {
              if (!day) return <div key={idx} />;

              const dateStr = formatDateStr(currentYear, currentMonth, day);
              const isToday = dateStr === todayStr;
              const isSelected = selectedDate === dateStr;

              return (
                <div
                  key={idx}
                  onClick={() => {
                    setSelectedDate(dateStr);
                    setShowForm(true);
                    setEditingId(null);
                    setFormData({
                      patientName: '',
                      date: dateStr,
                      time: '',
                      status: 'Scheduled',
                    });
                  }}
                  style={{
                    cursor: 'pointer',
                    padding: '8px',
                    borderRadius: '5px',
                    backgroundColor: isSelected
                      ? '#4caf50'
                      : isToday
                      ? '#90caf9'
                      : '#ffffff',
                    color: isSelected || isToday ? 'white' : 'black',
                    border: '1px solid #ddd',
                    textAlign: 'center',
                    userSelect: 'none',
                  }}
                  title={`Click to add appointment on ${dateStr}`}
                >
                  {day}
                </div>
              );
            })}
          </div>
        </section>

        {showForm && (
          <div className="modal-overlay" onClick={() => setShowForm(false)}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <h3>{editingId ? 'Edit Appointment' : 'Add Appointment'}</h3>
              <label>Patient Name</label>
              <input
                type="text"
                value={formData.patientName}
                onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
              />
              <label>Date</label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
              <label>Time</label>
              <input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              />
              <label>Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                style={{ color: statusColors[formData.status], fontWeight: '600' }}
              >
                <option value="Scheduled">Scheduled</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
              <div className="modal-actions">
                <button className="save-button" onClick={handleSubmit}>
                  {editingId ? 'Update' : 'Add'}
                </button>
                <button className="cancel-button" onClick={() => setShowForm(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorAppointmentPage;
