// src/pages/ResourceManagement.jsx
import React, { useState } from 'react';
import Sidebar from '../../components/AdminSidebar';
import TopBar from '../../components/AdminTopbar';
import '../../assets/css/Admin/AdminResourceManagement.css';
import { Plus } from 'lucide-react';

const ResourceManagement = () => {
  const [resources, setResources] = useState([
    { id: 1, name: 'MRI Machine', category: 'Imaging', status: 'Operational' },
    { id: 2, name: 'X-Ray Machine', category: 'Imaging', status: 'Under Maintenance' },
    { id: 3, name: 'Hospital Beds', category: 'Furniture', status: 'Available' },
    { id: 4, name: 'Wheelchairs', category: 'Mobility', status: 'Available' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [newResource, setNewResource] = useState({ name: '', category: '', status: '' });
  const [editResource, setEditResource] = useState({ id: null, name: '', category: '', status: '' });

  const filteredResources = resources.filter(
    res =>
      res.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      res.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddResource = () => {
    if (!newResource.name || !newResource.category || !newResource.status) {
      alert('Please fill in all fields');
      return;
    }
    const newItem = { id: 0, ...newResource }; // temporary id
    const updatedList = [newItem, ...resources];

    // Re-index IDs starting at 1
    const reIndexedList = updatedList.map((res, idx) => ({
      ...res,
      id: idx + 1,
    }));

    setResources(reIndexedList);
    setNewResource({ name: '', category: '', status: '' });
    setShowAddModal(false);
  };

  const handleEditClick = (resource) => {
    setEditResource(resource);
    setShowEditModal(true);
  };

  const handleUpdateResource = () => {
    if (!editResource.name || !editResource.category || !editResource.status) {
      alert('Please fill in all fields');
      return;
    }
    const updated = resources.map(r =>
      r.id === editResource.id ? editResource : r
    );
    setResources(updated);
    setShowEditModal(false);
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this resource?')) {
      const filtered = resources.filter(r => r.id !== id);
      const reIndexed = filtered.map((res, idx) => ({
        ...res,
        id: idx + 1,
      }));
      setResources(reIndexed);
    }
  };

  return (
    <div className="resource-management-wrapper">
      <Sidebar />
      <div className="resource-management-main">
        <TopBar />

        <div className="resource-management-container">
          <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
            <input
              type="text"
              placeholder="Search by name or category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{
                width: '280px',
                padding: '8px',
                fontSize: 16,
                borderRadius: 4,
                border: '1px solid #ccc',
              }}
            />
            <button
              onClick={() => setShowAddModal(true)}
              style={{
                display: 'flex',
                alignItems: 'center',
                backgroundColor: '#1E3A8A',
                color: 'white',
                border: 'none',
                padding: '8px 14px',
                fontSize: 16,
                cursor: 'pointer',
                borderRadius: 4,
                gap: 6,
              }}
            >
              <Plus size={16} />
              Add Resource
            </button>
          </div>

          <table className="resource-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Resource</th>
                <th>Category</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredResources.length === 0 ? (
                <tr>
                  <td colSpan="5" style={{ textAlign: 'center' }}>No resources found.</td>
                </tr>
              ) : (
                filteredResources.map((res) => (
                  <tr key={res.id}>
                    <td>{res.id}</td>
                    <td>{res.name}</td>
                    <td>{res.category}</td>
                    <td>{res.status}</td>
                    <td>
                      <button className="edit-btn" onClick={() => handleEditClick(res)}>Edit</button>
                      <button className="delete-btn" onClick={() => handleDelete(res.id)}>Delete</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Add Modal */}
          {showAddModal && (
            <div className="modal-overlay">
              <div className="modal-content">
                <h3>Add Resource</h3>
                <label>
                  Name:
                  <input
                    type="text"
                    value={newResource.name}
                    onChange={(e) => setNewResource({ ...newResource, name: e.target.value })}
                  />
                </label>
                <label>
                  Category:
                  <select
                    value={newResource.category}
                    onChange={(e) => setNewResource({ ...newResource, category: e.target.value })}
                  >
                    <option value="">-- Select Category --</option>
                    <option value="Imaging">Imaging</option>
                    <option value="Furniture">Furniture</option>
                    <option value="Mobility">Mobility</option>
                    <option value="Diagnostic">Diagnostic</option>
                    <option value="Surgical">Surgical</option>
                  </select>
                </label>
                <label>
                  Status:
                  <select
                    value={newResource.status}
                    onChange={(e) => setNewResource({ ...newResource, status: e.target.value })}
                  >
                    <option value="">-- Select Status --</option>
                    <option value="Operational">Operational</option>
                    <option value="Under Maintenance">Under Maintenance</option>
                    <option value="Available">Available</option>
                    <option value="Out of Service">Out of Service</option>
                  </select>
                </label>
                <div style={{ textAlign: 'right', marginTop: 16 }}>
                  <button onClick={() => setShowAddModal(false)} style={{ marginRight: 10 }}>Cancel</button>
                  <button onClick={handleAddResource}>Add</button>
                </div>
              </div>
            </div>
          )}

          {/* Edit Modal */}
          {showEditModal && (
            <div className="modal-overlay">
              <div className="modal-content">
                <h3>Edit Resource</h3>
                <label>
                  Name:
                  <input
                    type="text"
                    value={editResource.name}
                    onChange={(e) => setEditResource({ ...editResource, name: e.target.value })}
                  />
                </label>
                <label>
                  Category:
                  <select
                    value={editResource.category}
                    onChange={(e) => setEditResource({ ...editResource, category: e.target.value })}
                  >
                    <option value="">-- Select Category --</option>
                    <option value="Imaging">Imaging</option>
                    <option value="Furniture">Furniture</option>
                    <option value="Mobility">Mobility</option>
                    <option value="Diagnostic">Diagnostic</option>
                    <option value="Surgical">Surgical</option>
                  </select>
                </label>
                <label>
                  Status:
                  <select
                    value={editResource.status}
                    onChange={(e) => setEditResource({ ...editResource, status: e.target.value })}
                  >
                    <option value="">-- Select Status --</option>
                    <option value="Operational">Operational</option>
                    <option value="Under Maintenance">Under Maintenance</option>
                    <option value="Available">Available</option>
                    <option value="Out of Service">Out of Service</option>
                  </select>
                </label>
                <div style={{ textAlign: 'right', marginTop: 16 }}>
                  <button onClick={() => setShowEditModal(false)} style={{ marginRight: 10 }}>Cancel</button>
                  <button onClick={handleUpdateResource}>Update</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResourceManagement;
