// src/pages/AdminDashboard.jsx
import React, { useState } from 'react';
import '../../assets/css/Admin/AdminDashboard.css';
import Sidebar from '../../components/AdminSidebar';
import TopBar from '../../components/AdminTopbar';
import {
  Users,
  CreditCard,
  CalendarClock,
  FolderKanban,
  BarChart,
  ClipboardList,
  Settings,
  UserCheck,
  Stethoscope,
  BedDouble,
  UserPlus,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Edit2,
  Save,
  X,
} from 'lucide-react';


import { Link } from 'react-router-dom';

const hospitalActivitiesInitial = [
  { date: '2025-07-02', activity: 'Staff Meeting' },
  { date: '2025-07-05', activity: 'Inventory Check' },
  { date: '2025-07-10', activity: 'New Patient Orientation' },
  { date: '2025-07-15', activity: 'Maintenance' },
  { date: '2025-07-20', activity: 'Doctor Training' },
  { date: '2025-07-25', activity: 'Health Camp' },
  { date: '2025-08-03', activity: 'Emergency Drill' },
  { date: '2025-08-12', activity: 'Board Meeting' },
];

// Helpers
const getDaysInMonth = (year, month) => new Date(year, month + 1, 0).getDate();

const formatDate = (year, month, day) =>
  `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

const AdminDashboard = () => {
  const [currentYear, setCurrentYear] = useState(2025);
  const [currentMonth, setCurrentMonth] = useState(6); // July (0-based)

  const [hospitalActivities, setHospitalActivities] = useState(hospitalActivitiesInitial);

  const [selectedDay, setSelectedDay] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [editedActivity, setEditedActivity] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const daysInMonth = getDaysInMonth(currentYear, currentMonth);
  const daysArray = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const activitiesThisMonth = hospitalActivities.filter((act) => {
    const [y, m] = act.date.split('-');
    return Number(y) === currentYear && Number(m) - 1 === currentMonth;
  });

  const activityMap = new Map();
  activitiesThisMonth.forEach((act) => {
    const day = Number(act.date.split('-')[2]);
    activityMap.set(day, act.activity);
  });

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
    closeModal();
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
    closeModal();
  };

  const onDayClick = (day) => {
    const activity = activityMap.get(day) || '';
    setSelectedDay(day);
    setEditedActivity(activity);
    setEditMode(false);
    setIsModalOpen(true);
  };

  const saveEditedActivity = () => {
    if (!editedActivity.trim()) {
      alert('Activity cannot be empty');
      return;
    }
    const dateStr = formatDate(currentYear, currentMonth, selectedDay);

    // Check if activity for this date exists; if yes update else add new
    setHospitalActivities((prev) => {
      const exists = prev.some((act) => act.date === dateStr);
      if (exists) {
        return prev.map((act) =>
          act.date === dateStr ? { ...act, activity: editedActivity.trim() } : act
        );
      } else {
        return [...prev, { date: dateStr, activity: editedActivity.trim() }];
      }
    });

    setEditMode(false);
    setIsModalOpen(false);
  };

  const deleteActivity = () => {
    if (
      window.confirm(
        `Are you sure you want to delete the activity on ${formatDate(
          currentYear,
          currentMonth,
          selectedDay
        )}?`
      )
    ) {
      const dateStr = formatDate(currentYear, currentMonth, selectedDay);
      setHospitalActivities((prev) => prev.filter((act) => act.date !== dateStr));
      closeModal();
    }
  };

  const closeModal = () => {
    setSelectedDay(null);
    setEditMode(false);
    setIsModalOpen(false);
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];

  return (
    <div className="admin-dashboard">
      <div className="dashboard-layout">
        <Sidebar />
        <main className="main-content">
          <TopBar />

          {/* Summary Cards */}
          <div className="summary-cards">
            <div className="summary-card">
              <Users className="summary-icon" />
              <div>
                <h2>1500</h2>
                <p>Total Users</p>
              </div>
            </div>
            <div className="summary-card">
              <UserCheck className="summary-icon" />
              <div>
                <h2>850</h2>
                <p>Number of Patients</p>
              </div>
            </div>
            <div className="summary-card">
              <Stethoscope className="summary-icon" />
              <div>
                <h2>45</h2>
                <p>Number of Doctors</p>
              </div>
            </div>
            {/* <div className="summary-card">
              <BedDouble className="summary-icon" />
              <div>
                <h2>120</h2>
                <p>Available Beds</p>
              </div>
            </div> */}
            {/* <div className="summary-card">
              <BarChart className="summary-icon" />
              <div>
                <h2>320</h2>
                <p>Reports Generated</p>
              </div>
            </div> */}
            {/* <div className="summary-card">
              <ClipboardList className="summary-icon" />
              <div>
                <h2>57</h2>
                <p>Active Sessions</p>
              </div>
            </div> */}
            {/* <div className="summary-card">
              <CreditCard className="summary-icon" />
              <div>
                <h2>$45,320</h2>
                <p>Revenue</p>
              </div>
            </div> */}
            <div className="summary-card">
              <UserPlus className="summary-icon" />
              <div>
                <h2>32</h2>
                <p>New Registrations</p>
              </div>
            </div>
          </div>

          {/* Dashboard Cards */}
          <div className="card-grid">
            <Link to="/users" className="dashboard-card-link">
              <div className="dashboard-card">
                <Users className="dashboard-icon" />
                <h3>User Management</h3>
                <p>Manage roles and permissions.</p>
              </div>
            </Link>

            <Link to="/resources" className="dashboard-card-link">
              <div className="dashboard-card">
                <FolderKanban className="dashboard-icon" />
                <h3>Resource Management</h3>
                <p>Monitor inventory of supplies. </p>
              </div>
            </Link>

            <Link to="/appointments" className="dashboard-card-link">
              <div className="dashboard-card">
                <CalendarClock className="dashboard-icon" />
                <h3>Appointment Management</h3>
                <p>Schedule and Track Appointments</p>
              </div>
            </Link>

            <Link to="/billing" className="dashboard-card-link">
              <div className="dashboard-card">
                <CreditCard className="dashboard-icon" />
                <h3>Billing Management</h3>
                <p>Handle billing and payments.</p>
              </div>
            </Link>

            
          </div>

          {/* Calendar Section */}
          <div className="appointments-section">
            <div className="calendar-header">
              <button
                onClick={prevMonth}
                aria-label="Previous Month"
                className="calendar-nav-btn"
              >
                <ChevronLeft size={20} />
              </button>

              <h3>
               {monthNames[currentMonth]} {currentYear}
              </h3>

              <button
                onClick={nextMonth}
                aria-label="Next Month"
                className="calendar-nav-btn"
              >
                <ChevronRight size={20} />
              </button>
            </div>

            <div className="calendar-wrapper">
              <div className="calendar-grid">
                {daysArray.map((day) => {
                  const hasActivity = activityMap.has(day);
                  return (
                    <div
                      key={day}
                      className={`calendar-day ${hasActivity ? 'calendar-day-active' : ''}`}
                      title={hasActivity ? activityMap.get(day) : ''}
                      onClick={() => onDayClick(day)}
                    >
                      {day}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Modal for Add/Edit Activity */}
          {isModalOpen && (
            <div className="modal-overlay" onClick={closeModal}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <h4>
                  Activity on {formatDate(currentYear, currentMonth, selectedDay)}
                </h4>

                <textarea
                  value={editedActivity}
                  onChange={(e) => setEditedActivity(e.target.value)}
                  rows={4}
                  style={{ width: '90%', fontSize: '1.2rem' }}
                />

                <div className="activity-buttons" style={{ marginTop: '1rem' }}>
                  <button onClick={saveEditedActivity} className="btn btn-save">
                    <Save size={15} /> Save
                  </button>
                  {!editMode && activityMap.has(selectedDay) && (
                    <button onClick={deleteActivity} className="btn btn-delete" style={{ marginLeft: '10px' }}>
                      <Trash2 size={15} /> Delete
                    </button>
                  )}
                  <button
                    onClick={closeModal}
                    className="btn btn-cancel"
                    style={{ marginLeft: '10px' }}
                  >
                    Cancel
                    <X size={15} style={{ marginLeft: 4 }} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;

