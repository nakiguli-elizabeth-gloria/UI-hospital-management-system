// src/pages/NotificationsPage.jsx
import React, { useState } from 'react';
import Sidebar from '../../components/AdminSidebar'; // Change to DoctorSidebar if you have one
import TopBar from '../../components/AdminTopbar';   // Change to DoctorTopBar if available
import '../../assets/css/Admin/AdminNotificationsPage.css';

const initialNotifications = [
  { id: 1, title: 'New Patient Assigned', message: 'You have been assigned a new patient: John Doe.', date: '2025-07-18' },
  { id: 2, title: 'Upcoming Appointment', message: 'You have an appointment scheduled on 2025-07-20 at 10:00 AM.', date: '2025-07-17' },
  { id: 3, title: 'Staff Meeting Reminder', message: 'Reminder: Staff meeting on 2025-07-22 at 3:00 PM.', date: '2025-07-16' },
  { id: 4, title: 'System Update Notice', message: 'Scheduled system maintenance on 2025-07-25 from 1:00 AM to 3:00 AM.', date: '2025-07-15' },
];

const NotificationsPage = () => {
  const [notifications] = useState(initialNotifications);

  return (
    <div className="notifications-wrapper">
      <Sidebar />

      <main className="notifications-main">
        <TopBar />

        <section className="notification-page">
          <div className="notifications-container">
            {/* <h2 className="section-title">Notifications</h2> */}

            <div className="notifications-list">
              {notifications.length === 0 ? (
                <p className="no-results">No notifications available.</p>
              ) : (
                notifications.map(notification => (
                  <article
                    key={notification.id}
                    className="notification-item"
                    role="region"
                    aria-labelledby={`notification-title-${notification.id}`}
                  >
                    <h3
                      id={`notification-title-${notification.id}`}
                      className="notification-title"
                    >
                      {notification.title}
                    </h3>
                    <p className="notification-message">{notification.message}</p>
                    <time className="notification-date" dateTime={notification.date}>
                      {notification.date}
                    </time>
                  </article>
                ))
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default NotificationsPage;
