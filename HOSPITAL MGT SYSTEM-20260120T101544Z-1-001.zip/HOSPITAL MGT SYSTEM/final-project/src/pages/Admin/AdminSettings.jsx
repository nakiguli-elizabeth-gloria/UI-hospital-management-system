// src/pages/SettingsPage.jsx
import React, { useState } from 'react';
import Sidebar from '../../components/AdminSidebar';
import TopBar from '../../components/AdminTopbar';
import '../../assets/css/Admin/AdminSettings.css';

const SettingsPage = () => {
  const [permissions, setPermissions] = useState({
    doctor: {
      viewPatients: true,
      editPrescriptions: false,
      manageAppointments: true,
    },
    receptionist: {
      scheduleAppointments: true,
      managePatients: true,
      accessBilling: false,
    },
    pharmacist: {
      viewPrescriptions: true,
      dispenseMedication: true,
      manageInventory: false,
    },
  });

  const handleCheckboxChange = (role, permission) => {
    setPermissions((prev) => ({
      ...prev,
      [role]: {
        ...prev[role],
        [permission]: !prev[role][permission],
      },
    }));
  };

  return (
    <div className="settings-wrapper">
      <Sidebar />

      <div className="settings-main">
        <TopBar />

        <div className="settings-sections-container">
          {/* Profile Settings Section */}
          <div className="settings-section profile-settings">
            <h3>Edit Profile</h3>

            <div className="settings-group">
              <label>Name</label>
              <input type="text" placeholder="Admin Name" />
            </div>

            <div className="settings-group">
              <label>Email</label>
              <input type="email" placeholder="admin@example.com" />
            </div>

            <div className="settings-group">
              <label>Phone Number</label>
              <input type="tel" placeholder="+256 700000000" />
            </div>

            <div className="settings-group">
              <label>Change Password</label>
              <input type="password" placeholder="New Password" />
            </div>

            <div className="settings-group">
              <label>Confirm Password</label>
              <input type="password" placeholder="Confirm New Password" />
            </div>

            <button className="settings-save">Save Profile</button>
          </div>

          {/* Role Permissions Section */}
          <div className="settings-section role-permissions">
            <h3>Role Permissions</h3>

            {/* Doctor Permissions */}
            <div className="settings-group role-group">
              <h4>Doctor</h4>
              <p className="role-description">Control what doctors can access in the system.</p>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.doctor.viewPatients}
                  onChange={() => handleCheckboxChange('doctor', 'viewPatients')}
                />
                Can View Patient Records
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.doctor.editPrescriptions}
                  onChange={() => handleCheckboxChange('doctor', 'editPrescriptions')}
                />
                Can Edit Prescriptions
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.doctor.manageAppointments}
                  onChange={() => handleCheckboxChange('doctor', 'manageAppointments')}
                />
                Can Manage Appointments
              </label>
            </div>

            {/* Receptionist Permissions */}
            <div className="settings-group role-group">
              <h4>Receptionist</h4>
              <p className="role-description">Set permissions for front desk operations.</p>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.receptionist.scheduleAppointments}
                  onChange={() => handleCheckboxChange('receptionist', 'scheduleAppointments')}
                />
                Can Schedule Appointments
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.receptionist.managePatients}
                  onChange={() => handleCheckboxChange('receptionist', 'managePatients')}
                />
                Can Register & Manage Patients
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.receptionist.accessBilling}
                  onChange={() => handleCheckboxChange('receptionist', 'accessBilling')}
                />
                Can Access Billing Section
              </label>
            </div>

            {/* Pharmacist Permissions */}
            <div className="settings-group role-group">
              <h4>Pharmacist</h4>
              <p className="role-description">Manage access to medications and inventory.</p>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.pharmacist.viewPrescriptions}
                  onChange={() => handleCheckboxChange('pharmacist', 'viewPrescriptions')}
                />
                Can View Prescriptions
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.pharmacist.dispenseMedication}
                  onChange={() => handleCheckboxChange('pharmacist', 'dispenseMedication')}
                />
                Can Dispense Medication
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={permissions.pharmacist.manageInventory}
                  onChange={() => handleCheckboxChange('pharmacist', 'manageInventory')}
                />
                Can Manage Drug Inventory
              </label>
            </div>

            <button className="settings-save">Save Role Permissions</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
