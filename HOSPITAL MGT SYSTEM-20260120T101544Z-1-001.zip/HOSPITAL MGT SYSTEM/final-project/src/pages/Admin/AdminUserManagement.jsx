import React, { useState } from 'react';
import Sidebar from '../../components/AdminSidebar';
import TopBar from '../../components/AdminTopbar';
import '../../assets/css/Admin/AdminUserManagement.css';
import { Plus } from 'lucide-react';

const roles = ['Admin', 'Receptionist', 'Pharmacist', 'Doctor', 'Patient'];
const genders = ['Male', 'Female'];

const UserManagement = () => {
  const [users, setUsers] = useState([
    { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'Receptionist' },
    { id: 3, name: 'Mark Lee', email: 'mark@example.com', role: 'Pharmacist' },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: roles[0],
    gender: genders[0],
    password: '',
    confirmPassword: '',
  });

  const [showEditModal, setShowEditModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email || !newUser.password || !newUser.confirmPassword) {
      alert('Please fill all fields');
      return;
    }
    if (newUser.password !== newUser.confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    const userToAdd = {
      id: 0, // Temporary, will be reassigned
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      gender: newUser.gender,
      password: newUser.password,
    };

    const updatedUsers = [userToAdd, ...users];

    const reIndexedUsers = updatedUsers.map((user, index) => ({
      ...user,
      id: index + 1,
    }));

    setUsers(reIndexedUsers);

    setNewUser({
      name: '',
      email: '',
      role: roles[0],
      gender: genders[0],
      password: '',
      confirmPassword: '',
    });

    setShowAddModal(false);
  };

  const handleEditClick = (user) => {
    setEditingUser(user);
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    if (!editingUser.name || !editingUser.email) {
      alert('Please fill all fields');
      return;
    }

    const updatedUsers = users.map((u) =>
      u.id === editingUser.id ? editingUser : u
    );

    setUsers(updatedUsers);
    setEditingUser(null);
    setShowEditModal(false);
  };

  const handleDeleteUser = (id) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      const updatedUsers = users.filter((u) => u.id !== id).map((u, index) => ({
        ...u,
        id: index + 1,
      }));
      setUsers(updatedUsers);
    }
  };

  return (
    <div className="user-management-wrapper">
      <Sidebar />
      <div className="user-management-main">
        <TopBar />

        <div className="user-management-container">
          <div
            style={{
              marginBottom: 20,
              display: 'flex',
              gap: 10,
              alignItems: 'center',
            }}
          >
            <input
              type="text"
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
              style={{
                flexGrow: 1,
                padding: 8,
                fontSize: 16,
                borderRadius: 4,
                border: '1px solid #ccc',
              }}
            />
            <button
              onClick={() => setShowAddModal(true)}
              className="add-user-btn"
              style={{
                display: 'flex',
                alignItems: 'center',
                backgroundColor: '#1E3A8A',
                color: 'white',
                border: 'none',
                padding: '8px 14px',
                fontSize: 16,
                cursor: 'pointer',
                borderRadius: 4,
                gap: 6,
              }}
            >
              <Plus size={16} />
              Add User
            </button>
          </div>

          <table className="user-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: 20 }}>
                    No users found.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.role}</td>
                    <td>
                      <button
                        className="edit-btn"
                        style={{ marginRight: 8 }}
                        onClick={() => handleEditClick(user)}
                      >
                        Edit
                      </button>
                      <button
                        className="delete-btn"
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Add User Modal */}
          {showAddModal && (
            <div className="modal-overlay">
              <div className="modal-content">
                <h3>Add New User</h3>
                <label>
                  Name:
                  <input
                    type="text"
                    value={newUser.name}
                    onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  />
                </label>
                <label>
                  Email:
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  />
                </label>
                <label>
                  Gender:
                  <select
                    value={newUser.gender}
                    onChange={(e) => setNewUser({ ...newUser, gender: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  >
                    {genders.map((gender) => (
                      <option key={gender} value={gender}>
                        {gender}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Role:
                  <select
                    value={newUser.role}
                    onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  >
                    {roles.map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Password:
                  <input
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  />
                </label>
                <label>
                  Confirm Password:
                  <input
                    type="password"
                    value={newUser.confirmPassword}
                    onChange={(e) => setNewUser({ ...newUser, confirmPassword: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  />
                </label>
                <div style={{ marginTop: 16, textAlign: 'right' }}>
                  <button onClick={() => setShowAddModal(false)} style={{ marginRight: 10 }}>
                    Cancel
                  </button>
                  <button onClick={handleAddUser}>Add User</button>
                </div>
              </div>
            </div>
          )}

          {/* Edit User Modal */}
          {showEditModal && editingUser && (
            <div className="modal-overlay">
              <div className="modal-content">
                <h3>Edit User</h3>
                <label>
                  Name:
                  <input
                    type="text"
                    value={editingUser.name}
                    onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  />
                </label>
                <label>
                  Email:
                  <input
                    type="email"
                    value={editingUser.email}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  />
                </label>
                <label>
                  Role:
                  <select
                    value={editingUser.role}
                    onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value })}
                    style={{ width: '100%', padding: 8, margin: '8px 0' }}
                  >
                    {roles.map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                </label>
                <div style={{ marginTop: 16, textAlign: 'right' }}>
                  <button onClick={() => setShowEditModal(false)} style={{ marginRight: 10 }}>
                    Cancel
                  </button>
                  <button onClick={handleSaveEdit}>Save</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
