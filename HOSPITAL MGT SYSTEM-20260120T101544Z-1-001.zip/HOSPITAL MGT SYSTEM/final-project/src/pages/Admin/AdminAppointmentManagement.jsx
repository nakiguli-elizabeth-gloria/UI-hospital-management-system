import React, { useState } from 'react';
import Sidebar from '../../components/AdminSidebar';
import TopBar from '../../components/AdminTopbar';
import '../../assets/css/Admin/AdminAppointmentManagement.css';
import { Plus, CalendarClock } from 'lucide-react'; // ✅ Added CalendarClock icon

const initialAppointments = [
  { id: 1, patient: 'John Doe', doctor: 'Dr. Smith', date: '2025-07-20', time: '10:00' },
  { id: 2, patient: 'Jane Smith', doctor: 'Dr. Brown', date: '2025-07-21', time: '11:00' },
  { id: 3, patient: 'Mark Lee', doctor: 'Dr. Johnson', date: '2025-07-22', time: '14:00' },
];

const AppointmentManagement = () => {
  const [appointments, setAppointments] = useState(initialAppointments);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAppointment, setNewAppointment] = useState({ patient: '', doctor: '', date: '', time: '' });

  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState(null);

  const filteredAppointments = appointments.filter(appointment =>
    appointment.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
    appointment.doctor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddAppointment = () => {
    if (!newAppointment.patient || !newAppointment.doctor || !newAppointment.date || !newAppointment.time) {
      alert('Please fill all fields');
      return;
    }

    const newItem = { id: 0, ...newAppointment };
    const updatedList = [newItem, ...appointments];

    const reIndexedList = updatedList.map((appt, index) => ({
      ...appt,
      id: index + 1,
    }));

    setAppointments(reIndexedList);
    setNewAppointment({ patient: '', doctor: '', date: '', time: '' });
    setShowAddModal(false);
  };

  const handleEditClick = (appointment) => {
    setEditingAppointment(appointment);
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    if (!editingAppointment.patient || !editingAppointment.doctor || !editingAppointment.date || !editingAppointment.time) {
      alert('Please fill all fields');
      return;
    }
    const updatedAppointments = appointments.map(a => (a.id === editingAppointment.id ? editingAppointment : a));
    setAppointments(updatedAppointments);
    setEditingAppointment(null);
    setShowEditModal(false);
  };

  const handleDeleteAppointment = (id) => {
    if (window.confirm('Are you sure you want to delete this appointment?')) {
      const filtered = appointments.filter(a => a.id !== id);
      const reIndexed = filtered.map((appt, index) => ({
        ...appt,
        id: index + 1,
      }));
      setAppointments(reIndexed);
    }
  };

  return (
    <div className="appointment-management-wrapper">
      <Sidebar />

      <div className="appointment-management-main">
        <TopBar />

        <div className="appointment-management-container">
          {/* ✅ Icon Header
          <div className="header-with-icon">
            <CalendarClock size={24} className="dashboard-icon" />
            <h2>Appointment Management</h2>
          </div> */}

          <div className="top-controls">
            <input
              type="text"
              placeholder="Search by patient or doctor..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="search-input"
            />
            <button onClick={() => setShowAddModal(true)} className="add-appointment-btn">
              <Plus size={16} />
              Add Appointment
            </button>
          </div>

          <table className="appointment-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Date</th>
                <th>Time</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan="6" className="no-data">No appointments found.</td>
                </tr>
              ) : (
                filteredAppointments.map(appointment => (
                  <tr key={appointment.id}>
                    <td>{appointment.id}</td>
                    <td>{appointment.patient}</td>
                    <td>{appointment.doctor}</td>
                    <td>{appointment.date}</td>
                    <td>{appointment.time}</td>
                    <td>
                      <button className="edit-btn" onClick={() => handleEditClick(appointment)}>Edit</button>
                      <button className="delete-btn" onClick={() => handleDeleteAppointment(appointment.id)}>Delete</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Add Modal */}
          {showAddModal && (
            <div className="modal-overlay">
              <div className="modal-content">
                <h3>Add New Appointment</h3>
                <label>
                  Patient:
                  <input
                    type="text"
                    value={newAppointment.patient}
                    onChange={e => setNewAppointment({ ...newAppointment, patient: e.target.value })}
                  />
                </label>
                <label>
                  Doctor:
                  <input
                    type="text"
                    value={newAppointment.doctor}
                    onChange={e => setNewAppointment({ ...newAppointment, doctor: e.target.value })}
                  />
                </label>
                <label>
                  Date:
                  <input
                    type="date"
                    value={newAppointment.date}
                    onChange={e => setNewAppointment({ ...newAppointment, date: e.target.value })}
                  />
                </label>
                <label>
                  Time:
                  <input
                    type="time"
                    value={newAppointment.time}
                    onChange={e => setNewAppointment({ ...newAppointment, time: e.target.value })}
                  />
                </label>
                <div className="modal-actions">
                  <button onClick={() => setShowAddModal(false)} className="cancel-btn">Cancel</button>
                  <button onClick={handleAddAppointment} className="save-btn">Add</button>
                </div>
              </div>
            </div>
          )}

          {/* Edit Modal */}
          {showEditModal && editingAppointment && (
            <div className="modal-overlay">
              <div className="modal-content">
                <h3>Edit Appointment</h3>
                <label>
                  Patient:
                  <input
                    type="text"
                    value={editingAppointment.patient}
                    onChange={e => setEditingAppointment({ ...editingAppointment, patient: e.target.value })}
                  />
                </label>
                <label>
                  Doctor:
                  <input
                    type="text"
                    value={editingAppointment.doctor}
                    onChange={e => setEditingAppointment({ ...editingAppointment, doctor: e.target.value })}
                  />
                </label>
                <label>
                  Date:
                  <input
                    type="date"
                    value={editingAppointment.date}
                    onChange={e => setEditingAppointment({ ...editingAppointment, date: e.target.value })}
                  />
                </label>
                <label>
                  Time:
                  <input
                    type="time"
                    value={editingAppointment.time}
                    onChange={e => setEditingAppointment({ ...editingAppointment, time: e.target.value })}
                  />
                </label>
                <div className="modal-actions">
                  <button onClick={() => setShowEditModal(false)} className="cancel-btn">Cancel</button>
                  <button onClick={handleSaveEdit} className="save-btn">Save</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AppointmentManagement;
