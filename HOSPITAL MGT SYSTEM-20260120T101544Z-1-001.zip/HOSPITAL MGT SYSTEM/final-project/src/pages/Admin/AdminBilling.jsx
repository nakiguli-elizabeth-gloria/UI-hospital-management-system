import React, { useState } from 'react';
import Sidebar from '../../components/AdminSidebar';
import TopBar from '../../components/AdminTopbar';
import '../../assets/css/Admin/AdminBilling.css';

// Sample bills data
const initialBills = [
  { id: 1, patient: 'John Doe', service: 'Consultation', amount: 'UGX 50,000', status: 'Paid' },
  { id: 2, patient: 'Jane Smith', service: 'X-ray', amount: 'UGX 80,000', status: 'Pending' },
  { id: 3, patient: 'Mark Lee', service: 'Lab Tests', amount: 'UGX 120,000', status: 'Cancelled' },
];

// Map status to CSS classes for color (used for option and select)
const statusColors = {
  Paid: 'status-paid',
  Pending: 'status-pending',
  Cancelled: 'status-cancelled',
};

// Map status to color codes for inline select text color
const statusTextColors = {
  Paid: '#16a34a',       // green
  Pending: '#f97316',    // orange
  Cancelled: '#dc2626',  // red
};

const statusOptions = ['Paid', 'Pending', 'Cancelled'];

const BillingPage = () => {
  const [bills, setBills] = useState(initialBills);
  const [selectedBill, setSelectedBill] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleViewBill = (bill) => {
    setSelectedBill(bill);
  };

  const handlePrintBill = (bill) => {
    const printContent = `
      <div>
        <h2>Bill Details</h2>
        <p><strong>Patient:</strong> ${bill.patient}</p>
        <p><strong>Service:</strong> ${bill.service}</p>
        <p><strong>Amount:</strong> ${bill.amount}</p>
        <p><strong>Status:</strong> ${bill.status}</p>
      </div>
    `;
    const newWindow = window.open('', '_blank', 'width=600,height=400');
    newWindow.document.write(printContent);
    newWindow.document.close();
    newWindow.print();
  };

  const handleStatusChange = (id, newStatus) => {
    const updatedBills = bills.map((bill) =>
      bill.id === id ? { ...bill, status: newStatus } : bill
    );
    setBills(updatedBills);
  };

  const filteredBills = bills.filter(bill =>
    bill.patient.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="billing-wrapper">
      <Sidebar />
      <div className="billing-main">
        <TopBar />
        <div className="billing-container">
          <div className="search-bar">
            <input
              type="text"
              placeholder="Search by patient name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <table className="billing-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Patient</th>
                <th>Service</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBills.length > 0 ? (
                filteredBills.map((bill) => (
                  <tr key={bill.id}>
                    <td>{bill.id}</td>
                    <td>{bill.patient}</td>
                    <td>{bill.service}</td>
                    <td>{bill.amount}</td>
                    <td>
                      <select
                        value={bill.status}
                        onChange={(e) => handleStatusChange(bill.id, e.target.value)}
                        className={`status-dropdown ${statusColors[bill.status]}`}
                        style={{ color: statusTextColors[bill.status] }}
                      >
                        {statusOptions.map((option) => (
                          <option
                            key={option}
                            value={option}
                            className={statusColors[option]}
                            style={{ color: statusTextColors[option] }}
                          >
                            {option}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td>
                      {/* Uncomment below to enable view button */}
                      {/* <button className="view-btn" onClick={() => handleViewBill(bill)}>
                        View
                      </button> */}
                      <button className="print-btn" onClick={() => handlePrintBill(bill)}>
                        Print
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center' }}>No bills found.</td>
                </tr>
              )}
            </tbody>
          </table>

          {selectedBill && (
            <div className="modal-overlay" onClick={() => setSelectedBill(null)}>
              <div className="modal-content" onClick={e => e.stopPropagation()}>
                <h3>Bill Details</h3>
                <p><strong>Patient:</strong> {selectedBill.patient}</p>
                <p><strong>Service:</strong> {selectedBill.service}</p>
                <p><strong>Amount:</strong> {selectedBill.amount}</p>
                <p><strong>Status:</strong> {selectedBill.status}</p>
                <button onClick={() => setSelectedBill(null)} className="cancel-btn">
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BillingPage;
