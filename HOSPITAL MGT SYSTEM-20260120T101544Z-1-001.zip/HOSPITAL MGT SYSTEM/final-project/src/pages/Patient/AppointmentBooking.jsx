import React from 'react';
import { useNavigate } from 'react-router-dom'; // <-- Import navigate hook
import '../../assets/css/Patient/Appointment-booking.css';
import appointmentImage from '../../assets/images/appointment-image.jpg'; 

const AppointmentBooking = () => {
  const navigate = useNavigate(); // <-- Initialize navigation

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can add form validation or state saving logic here
    navigate('/appointment-confirmation'); // <-- Redirect to confirmation page
  };

  return (
    <div className="appointmentbooking-container">
      <div className="appointment-image">
        <img src={appointmentImage} alt="Appointmentbooking Visual" />
      </div>

      <div className="appointmentbooking-form">
        <div className="appointmentbooking-header">
          <h1 className="company-name">CITY CARE</h1>
          <p className="company-slogan">Your Health Care</p>
        </div>

        <h2>Please Enter Your Details</h2>
        <form onSubmit={handleSubmit}>
          <label>Name</label>
          <input type="text" required />

          <label>Phone Number</label>
          <input type="text" required />

          <label>Email address</label>
          <input type="email" placeholder="Enter your email" required />

          <label>Gender</label>
          <select className="appointmentbooking-dropdown" required>
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>

          <label>Service Of Interest</label>
          <select className="appointmentbooking-dropdown" required>
            <option value="">Select Service</option>
            <option value="consultation">Consultation</option>
            <option value="emergency">Emergency Room Services</option>
            <option value="xray">X-rays</option>
            <option value="antenatal">Antenatal Care</option>
            <option value="pediatric">Pediatric Care</option>
            <option value="physiotherapy">Physiotherapy</option>
            <option value="opthamology">Opthamology</option>
            <option value="counseling">Counseling</option>
            <option value="adminservices">Administrative services</option>
          </select>

          <label>Select an Appointment Date</label>
          <input type="date" className="appointmentbooking-dropdown" required />

          <label>Preferred Appointment Time</label>
          <input type="time" className="appointmentbooking-dropdown" required />

          <button type="submit">NEXT</button>
        </form>
      </div>
    </div>
  );
};

export default AppointmentBooking;
