// src/pages/HospitalWebsiteBooking.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom'; // for navigation
import '../../assets/css/Patient/HospitalWebsiteBooking.css';

const HospitalWebsiteBooking = () => {
  const navigate = useNavigate(); // initialize navigation

  const handleAppointmentClick = () => {
    navigate('/appointment-booking'); // navigate to appointment booking page
  };

  return (
    <div className="hospital-landing">
      {/* Top Navbar */}
      <header className="hospital-navbar">
        <div className="nav-container">
          <div className="hospital-logo">CityCare General Hospital</div>
          <nav className="nav-links">
            <a href="#">Home</a>
            <a href="#">Services</a>
            <a href="#">Doctors</a>
            <a href="#">Departments</a>
            <a href="#">Contact</a>
            <button className="appointment-btn" onClick={handleAppointmentClick}>
              Request for Appointment
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero-text-section">
        <div className="hero-content">
          <h1>Get Quality Care</h1>
          <p>For You and Your Family</p>
          <div className="hero-buttons">
            <button className="btn-white">View Departments</button>
            <button className="btn-outline">Get in Touch</button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HospitalWebsiteBooking;
