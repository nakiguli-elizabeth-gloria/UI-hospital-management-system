import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import '../../assets/css/Patient/AppointmentConfirmation.css';
import appointmentImage from '../../assets/images/appointment-image.jpg';

const AppointmentConfirmation = () => {
  const navigate = useNavigate(); // Initialize navigation

  const handleBackClick = () => {
    navigate('/'); // Navigate back to hospital website landing page
  };

  return (
    <div className="appointmentconfirmation-container">
      {/* Right-side image */}
      <div className="appointment-image">
        <img src={appointmentImage} alt="Appointment confirmation visual" />
      </div>

      {/* Left-side text content */}
      <div className="appointmentconfirmation-form">
        <div>
          <div className="appointmentconfirmation-header">
            <h1 className="company-name">CITY CARE</h1>
            <p className="company-slogan">Your Health Care</p>
          </div>

          <h2>APPOINTMENT DETAILS</h2>

          <h2 className="info-line">NAME: MIREMBE RITAH</h2>
          <h2 className="info-line">DATE: 25th, AUGUST, 2025</h2>
          <h2 className="info-line">TIME: 9:00 AM</h2>
          <h2 className="info-line">SERVICE: CONSULTATION</h2>
        </div>

        <button type="button" onClick={handleBackClick}>BACK</button>
      </div>
    </div>
  );
};

export default AppointmentConfirmation;
