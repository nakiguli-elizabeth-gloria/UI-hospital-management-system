import React from 'react';
import { useNavigate } from 'react-router-dom'; // ✅ Import
import '../assets/css/Login.css';
import loginImage from '../assets/images/login-image.jpg';
import logo from '../assets/images/logo.png'// Assuming you have a Logo component

const LoginPage = () => {
  const navigate = useNavigate(); // ✅ Initialize the hook

  const handleLogin = (e) => {
    e.preventDefault(); // Prevent page reload
    // You could add authentication logic here
    navigate('/admin-dashboard'); // ✅ Redirect to Admin Dashboard
  };

  return (
    <div className="login-container">
      <div className="login-logo">
      <img src={logo} alt="City Care Logo" />
    </div>
      <div className="login-image">
        <img src={loginImage} alt="Login Visual" />
      </div>
      <div className="login-form">
        <div className="login-header">
          <h1 className="company-name">CITY CARE</h1>
          <p className="company-slogan">Your Health Care</p>
        </div>

        <h2>Please Log In</h2>
        <form onSubmit={handleLogin}>
          <label>User Role</label>
          <select className="login-dropdown">
            <option value="admin">Admin</option>
            <option value="admin">Doctor</option>
            <option value="receptionist">Pharmacist</option>
            <option value="pharmacist">Receptionist</option>
          </select>

          <label>Email address</label>
          <input type="email" placeholder="Enter your email" />

          <label>Password</label>
          <input type="password" placeholder="Enter your password" />

          <div className="forgot-password">
            <a href="/forgot-password">Forgot Password?</a>
          </div>

          <button type="submit">LOGIN</button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
