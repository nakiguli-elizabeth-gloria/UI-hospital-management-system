// src/pages/Pharmacist/PharmacistNotificationsPage.jsx

import React, { useState } from 'react';
import PharmacistSidebar from '../../components/PharmacistSidebar';
import PharmacistTopbar from '../../components/PharmacistTopbar';
import '../../assets/css/Pharmacist/PharmacistNotificationsPage.css';

const sampleNotifications = [
  {
    id: 1,
    title: 'New Prescription',
    message: 'You have received a new prescription for patient John Doe.',
    date: '2025-07-17',
  },
  {
    id: 2,
    title: 'Low Stock Alert',
    message: 'Paracetamol stock is below minimum threshold. Please reorder.',
    date: '2025-07-16',
  },
  {
    id: 3,
    title: 'Staff Message',
    message: 'Reminder: Pharmacy team meeting at 3:00 PM in the break room.',
    date: '2025-07-15',
  },
];

const PharmacistNotificationsPage = () => {
  const [notifications] = useState(sampleNotifications);

  return (
    <div className="pharmacist-notifications-page">
      <PharmacistSidebar />
      <div className="main-content">
        <PharmacistTopbar title="Notifications" />

        <div className="content-area">
          {/* <h2 className="page-title">Notifications</h2> */}

          {notifications.length === 0 ? (
            <p className="no-notifications">No new notifications.</p>
          ) : (
            <div className="notification-grid">
              {notifications.map((notification) => (
                <div key={notification.id} className="notification-card">
                  <div className="notification-header">
                    <h3 className="notification-title">{notification.title}</h3>
                    <span className="notification-date">{notification.date}</span>
                  </div>
                  <p className="notification-message">{notification.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PharmacistNotificationsPage;
