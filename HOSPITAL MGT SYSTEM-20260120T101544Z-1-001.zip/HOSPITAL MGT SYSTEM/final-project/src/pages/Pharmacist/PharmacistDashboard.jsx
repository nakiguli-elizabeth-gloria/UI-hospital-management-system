// src/pages/PharmacistDashboard.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../../assets/css/Pharmacist/PharmacistDashboard.css';
import PharmacistSidebar from '../../components/PharmacistSidebar';
import PharmacistTopBar from '../../components/PharmacistTopbar';
import {
  Users,
  Boxes,
  FileText,
  Settings,
  ClipboardList,
  AlertCircle,
  RefreshCcw,
  BarChart2,
} from 'lucide-react';

const PharmacistDashboard = () => {
  const [orders, setOrders] = useState([
    { id: 1, patientName: 'John Doe', medicine: 'Amoxicillin', doctorName: 'Dr. Adams', status: 'Pending' },
    { id: 2, patientName: 'Jane Smith', medicine: 'Paracetamol', doctorName: 'Dr. Brown', status: 'Completed' },
    { id: 3, patientName: 'Emily Clark', medicine: 'Ibuprofen', doctorName: 'Dr. Carter', status: 'Pending' },
  ]);

  const handleUpdateOrderStatus = (orderId, status) => {
    const updatedOrders = orders.map((order) =>
      order.id === orderId ? { ...order, status } : order
    );
    setOrders(updatedOrders);
  };

  return (
    <div className="pharmacist-dashboard">
      <PharmacistSidebar />
      <div className="main-content">
        <PharmacistTopBar />
        <div className="dashboard-content">
          {/* Dashboard Cards */}

          <div className="card-grid">
            <Link to="/pharmacist-patientinfo" className="dashboard-card">
              <Users className="dashboard-icon" />
              <h3>Manage Patients</h3>
              <p>View & update patient prescriptions.</p>
            </Link>

            <Link to="/pharmacist-inventory" className="dashboard-card">
              <Boxes className="dashboard-icon" />
              <h3>Manage Inventory</h3>
              <p>Monitor stock levels and medicines.</p>
            </Link>

            <Link to="/pharmacist-billing" className="dashboard-card">
              <FileText className="dashboard-icon" />
              <h3>Billing</h3>
              <p>Generate and manage invoices.</p>
            </Link>

            {/* <Link to="/pharmacist-prescrptionhistory" className="dashboard-card">
              <Settings className="dashboard-icon" />
              <h3>Prescription History</h3>
              <p>Review past prescriptions and patient records.</p>
            </Link> */}

            
          </div>
        </div>
      </div>
    </div>
  );
};

export default PharmacistDashboard;
