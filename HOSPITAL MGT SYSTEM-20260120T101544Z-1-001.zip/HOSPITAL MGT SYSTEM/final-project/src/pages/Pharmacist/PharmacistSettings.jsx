// src/pages/Pharmacist/PharmacistSettings.jsx

import React, { useState } from 'react';
import '../../assets/css/Pharmacist/PharmacistSettings.css';
import PharmacistSidebar from '../../components/PharmacistSidebar';
import PharmacistTopBar from '../../components/PharmacistTopbar';

const PharmacistSettings = () => {
  const [profile, setProfile] = useState({
    name: 'Alex Pharma',
    email: 'alex@pharmacy.com',
    phone: '555-1234',
  });

  const [passwords, setPasswords] = useState({
    current: '',
    new: '',
    confirm: '',
  });

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswords({ ...passwords, [name]: value });
  };

  const saveProfile = () => {
    // Simulate API call
    alert('Profile information updated successfully!');
  };

  const changePassword = () => {
    if (!passwords.current || !passwords.new || !passwords.confirm) {
      alert('Please fill in all password fields.');
    } else if (passwords.new !== passwords.confirm) {
      alert('New passwords do not match!');
    } else {
      alert('Password changed successfully!');
    }
  };

  return (
    <div className="pharmacist-settings-page">
      <PharmacistSidebar />
      <div className="main-content">
        <PharmacistTopBar title="Settings" />
        <div className="settings-container">
          <form className="settings-form" onSubmit={(e) => e.preventDefault()}>
            {/* === Profile Section === */}
            <div className="form-section">
              <h3 className="section-title">Profile Information</h3>
              <label>
                Full Name
                <input
                  type="text"
                  name="name"
                  value={profile.name}
                  onChange={handleProfileChange}
                  placeholder="Full Name"
                />
              </label>
              <label>
                Email Address
                <input
                  type="email"
                  name="email"
                  value={profile.email}
                  onChange={handleProfileChange}
                  placeholder="Email"
                />
              </label>
              <label>
                Phone Number
                <input
                  type="tel"
                  name="phone"
                  value={profile.phone}
                  onChange={handleProfileChange}
                  placeholder="Phone Number"
                />
              </label>
              <button type="button" className="save-btn" onClick={saveProfile}>
                Save Profile
              </button>
            </div>

            {/* === Password Section === */}
            <div className="form-section">
              <h3 className="section-title">Change Password</h3>
              <label>
                Current Password
                <input
                  type="password"
                  name="current"
                  value={passwords.current}
                  onChange={handlePasswordChange}
                  placeholder="Current Password"
                />
              </label>
              <label>
                New Password
                <input
                  type="password"
                  name="new"
                  value={passwords.new}
                  onChange={handlePasswordChange}
                  placeholder="New Password"
                />
              </label>
              <label>
                Confirm New Password
                <input
                  type="password"
                  name="confirm"
                  value={passwords.confirm}
                  onChange={handlePasswordChange}
                  placeholder="Confirm New Password"
                />
              </label>
              <button type="button" className="save-btn" onClick={changePassword}>
                Update Password
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PharmacistSettings;
