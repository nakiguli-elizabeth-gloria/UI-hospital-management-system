import React, { useState } from 'react';
import '../../assets/css/Pharmacist/PharmacistPrescriptionHistory.css';
import PharmacistSidebar from '../../components/PharmacistSidebar';
import PharmacistTopBar from '../../components/PharmacistTopbar';

const PharmacistPrescriptionHistory = () => {
  const [prescriptions, setPrescriptions] = useState([
    {
      id: 1,
      patientName: 'John Doe',
      doctorName: 'Dr. Smith',
      date: '2025-07-01',
      medicines: ['Amoxicillin 500mg', 'Paracetamol 650mg'],
      status: 'Dispensed',
    },
    {
      id: 2,
      patientName: 'Emily Clark',
      doctorName: 'Dr. Adams',
      date: '2025-06-20',
      medicines: ['Ibuprofen 200mg'],
      status: 'Pending',
    },
    {
      id: 3,
      patientName: 'Jane Smith',
      doctorName: 'Dr. Green',
      date: '2025-06-15',
      medicines: ['Cetirizine 10mg', 'Vitamin D 1000IU'],
      status: 'Dispensed',
    },
  ]);

  const handleStatusChange = (id, newStatus) => {
    const updated = prescriptions.map(p =>
      p.id === id ? { ...p, status: newStatus } : p
    );
    setPrescriptions(updated);
  };

  return (
    <div className="prescription-history-page">
      <PharmacistSidebar />
      <div className="main-content">
        <PharmacistTopBar />
        <h2>Prescription History</h2>

        <div className="prescription-history">
          <table className="history-table">
            <thead>
              <tr>
                <th>Patient</th>
                <th>Doctor</th>
                <th>Date</th>
                <th>Medicines</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {prescriptions.map((prescription) => (
                <tr key={prescription.id}>
                  <td>{prescription.patientName}</td>
                  <td>{prescription.doctorName}</td>
                  <td>{prescription.date}</td>
                  <td>
                    <ul>
                      {prescription.medicines.map((med, i) => (
                        <li key={i}>{med}</li>
                      ))}
                    </ul>
                  </td>
                  <td>
                    <select
                      value={prescription.status}
                      onChange={(e) => handleStatusChange(prescription.id, e.target.value)}
                      className={`status-select ${prescription.status.toLowerCase()}`}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Dispensed">Dispensed</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PharmacistPrescriptionHistory;
