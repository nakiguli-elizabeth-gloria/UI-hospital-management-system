import React, { useState } from 'react';
import '../../assets/css/Pharmacist/PharmacistPatientInfo.css';
import PharmacistSidebar from '../../components/PharmacistSidebar';
import PharmacistTopbar from '../../components/PharmacistTopbar';

const PharmacistPatientInfo = () => {
  const initialPatients = [
    {
      id: 1,
      name: 'John Doe',
      address: '123 Main St',
      contact: '555-1234',
      prescriptions: [
        { id: 1, date: '2025-07-10', medicine: 'Amoxicillin', dosage: '500mg', frequency: 'Twice a day', doctor: 'Dr. Adams' },
        { id: 2, date: '2025-06-15', medicine: 'Insulin', dosage: '20 units', frequency: 'Daily', doctor: 'Dr. Smith' },
      ],
    },
    {
      id: 2,
      name: 'Jane Smith',
      address: '456 Oak Ave',
      contact: '555-5678',
      prescriptions: [
        { id: 3, date: '2025-07-12', medicine: 'Lisinopril', dosage: '10mg', frequency: 'Once a day', doctor: 'Dr. Brown' },
      ],
    },
  ];

  const [patients, setPatients] = useState(initialPatients);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showAddPrescriptionModal, setShowAddPrescriptionModal] = useState(false);
  const [showEditPatientModal, setShowEditPatientModal] = useState(false);

  const [newPrescription, setNewPrescription] = useState({
    medicine: '',
    dosage: '',
    frequency: '',
    doctor: '',
  });

  const [editPatientData, setEditPatientData] = useState({
    id: null,
    name: '',
    address: '',
    contact: '',
  });

  // Filter patients by name
  const filteredPatients = patients.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handlers for Prescription modal
  const handlePrescriptionChange = (e) => {
    const { name, value } = e.target;
    setNewPrescription(prev => ({ ...prev, [name]: value }));
  };

  const handleSavePrescription = () => {
    if (!newPrescription.medicine || !newPrescription.dosage || !newPrescription.frequency || !newPrescription.doctor) {
      alert('Please fill all prescription fields.');
      return;
    }

    setPatients(prevPatients =>
      prevPatients.map(patient => {
        if (patient.id === selectedPatient.id) {
          const updatedPrescriptions = [
            ...(patient.prescriptions || []),
            { id: Date.now(), date: new Date().toISOString().slice(0, 10), ...newPrescription },
          ];
          return { ...patient, prescriptions: updatedPrescriptions };
        }
        return patient;
      })
    );

    alert(`Prescription added for ${selectedPatient.name}`);
    setNewPrescription({ medicine: '', dosage: '', frequency: '', doctor: '' });
    setShowAddPrescriptionModal(false);
    setSelectedPatient(null);
  };

  const closeAddPrescriptionModal = () => {
    setShowAddPrescriptionModal(false);
    setSelectedPatient(null);
  };

  // Handlers for Edit Patient modal
  const openEditPatientModal = (patient) => {
    setEditPatientData({
      id: patient.id,
      name: patient.name,
      address: patient.address,
      contact: patient.contact,
    });
    setShowEditPatientModal(true);
  };

  const handleEditPatientChange = (e) => {
    const { name, value } = e.target;
    setEditPatientData(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveEditedPatient = () => {
    if (!editPatientData.name || !editPatientData.address || !editPatientData.contact) {
      alert('Please fill all patient fields.');
      return;
    }

    setPatients(prevPatients =>
      prevPatients.map(patient =>
        patient.id === editPatientData.id
          ? { ...patient, ...editPatientData }
          : patient
      )
    );

    alert(`Patient ${editPatientData.name} updated.`);
    setShowEditPatientModal(false);
    setEditPatientData({ id: null, name: '', address: '', contact: '' });
  };

  const closeEditPatientModal = () => {
    setShowEditPatientModal(false);
  };

  // View Prescription History modal close
  const closePrescriptionHistoryModal = () => {
    setSelectedPatient(null);
  };

  return (
    <div>
      <PharmacistSidebar />
      <PharmacistTopbar />
      <div className="pharmacist-patient-info-page">
        <main className="main-content">
          <div className="page-header">
            <div>
              <input
                type="text"
                placeholder="Search patient by name..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="search-input"
              />
            </div>
          </div>

          {filteredPatients.length > 0 ? (
            <div className="table-container">
              <table className="patients-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPatients.map(patient => (
                    <tr key={patient.id}>
                      <td>{patient.name}</td>
                      <td>{patient.address}</td>
                      <td>{patient.contact}</td>
                      <td>
                        <button
  className="view-btn action-btn"
  onClick={() => {
    setSelectedPatient(patient);
    setShowAddPrescriptionModal(false);
  }}
>
  View History
</button>

                        <button
  className="current-btn action-btn"
  onClick={() => {
    setSelectedPatient(patient);
    setShowAddPrescriptionModal(true);
  }}
>
  Add Prescription
</button>

                        <button
  className="edit-btn action-btn"
  onClick={() => openEditPatientModal(patient)}
>
  Edit
</button>

                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="no-data">No patients found.</p>
          )}

          {/* Edit Patient Modal */}
          {showEditPatientModal && (
            <div className="modal-overlay" onClick={closeEditPatientModal}>
              <div className="modal-content" onClick={e => e.stopPropagation()}>
                <h3>Edit Patient</h3>
                <label>Name</label>
                <input
                  type="text"
                  name="name"
                  value={editPatientData.name}
                  onChange={handleEditPatientChange}
                  placeholder="Patient Name"
                />
                <label>Address</label>
                <input
                  type="text"
                  name="address"
                  value={editPatientData.address}
                  onChange={handleEditPatientChange}
                  placeholder="Patient Address"
                />
                <label>Contact</label>
                <input
                  type="tel"
                  name="contact"
                  value={editPatientData.contact}
                  onChange={handleEditPatientChange}
                  placeholder="Contact"
                />
                <div style={{ marginTop: '15px' }}>
                  <button onClick={handleSaveEditedPatient} className="save-button">
                    Save Changes
                  </button>
                  <button
                    onClick={closeEditPatientModal}
                    className="cancel-button"
                    style={{ marginLeft: '10px' }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Prescription History Modal */}
          {selectedPatient && !showAddPrescriptionModal && !showEditPatientModal && (
            <div className="modal-overlay" onClick={closePrescriptionHistoryModal}>
              <div className="modal-content" onClick={e => e.stopPropagation()}>
                <h3>{selectedPatient.name}'s Prescription History</h3>
                {selectedPatient.prescriptions.length === 0 ? (
                  <p>No prescriptions available.</p>
                ) : (
                  <table className="prescription-history-table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Medicine</th>
                        <th>Dosage</th>
                        <th>Frequency</th>
                        <th>Doctor</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedPatient.prescriptions.map(pr => (
                        <tr key={pr.id}>
                          <td>{pr.date}</td>
                          <td>{pr.medicine}</td>
                          <td>{pr.dosage}</td>
                          <td>{pr.frequency}</td>
                          <td>{pr.doctor}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                <button onClick={closePrescriptionHistoryModal} className="cancel-button">
                  Close
                </button>
              </div>
            </div>
          )}

          {/* Add Prescription Modal */}
          {showAddPrescriptionModal && selectedPatient && (
            <div className="modal-overlay" onClick={closeAddPrescriptionModal}>
              <div className="modal-content" onClick={e => e.stopPropagation()}>
                <h3>Add Prescription for {selectedPatient.name}</h3>
                <label>Medicine</label>
                <input
                  type="text"
                  name="medicine"
                  value={newPrescription.medicine}
                  onChange={handlePrescriptionChange}
                  placeholder="Enter medicine"
                />
                <label>Dosage</label>
                <input
                  type="text"
                  name="dosage"
                  value={newPrescription.dosage}
                  onChange={handlePrescriptionChange}
                  placeholder="Enter dosage"
                />
                <label>Frequency</label>
                <input
                  type="text"
                  name="frequency"
                  value={newPrescription.frequency}
                  onChange={handlePrescriptionChange}
                  placeholder="Enter frequency"
                />
                <label>Doctor</label>
                <input
                  type="text"
                  name="doctor"
                  value={newPrescription.doctor}
                  onChange={handlePrescriptionChange}
                  placeholder="Enter doctor name"
                />
                <div style={{ marginTop: '15px' }}>
                  <button onClick={handleSavePrescription} className="save-button">
                    Save Prescription
                  </button>
                  <button
                    onClick={closeAddPrescriptionModal}
                    className="cancel-button"
                    style={{ marginLeft: '10px' }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default PharmacistPatientInfo;
