import React, { useState } from 'react';
import Sidebar from '../../components/PharmacistSidebar'; // Adjust if needed
import TopBar from '../../components/PharmacistTopbar';   // Adjust if needed
import '../../assets/css/Pharmacist/PharmacistInventory.css';
import { Plus } from 'lucide-react';

const statuses = ['In Stock', 'Low Stock', 'Out of Stock'];

const PharmacyInventory = () => {
  const [medicines, setMedicines] = useState([
    { id: 1, name: 'Paracetamol', quantity: 100, status: 'In Stock' },
    { id: 2, name: 'Ibuprofen', quantity: 20, status: 'Low Stock' },
    { id: 3, name: 'Amoxicillin', quantity: 0, status: 'Out of Stock' },
  ]);

  
  const [searchTerm, setSearchTerm] = useState('');
  const [restockModalVisible, setRestockModalVisible] = useState(false);
  const [selectedMedicine, setSelectedMedicine] = useState(null);
  const [restockAmount, setRestockAmount] = useState('');

  const [showAddModal, setShowAddModal] = useState(false);
  const [newMedicine, setNewMedicine] = useState({
    name: '',
    quantity: '',
    status: statuses[0],
  });

  const filteredMedicines = medicines.filter((med) =>
    med.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleStatusChange = (id, newStatus) => {
    const updated = medicines.map((med) =>
      med.id === id ? { ...med, status: newStatus } : med
    );
    setMedicines(updated);
  };

  const openRestockModal = (medicine) => {
    setSelectedMedicine(medicine);
    setRestockAmount('');
    setRestockModalVisible(true);
  };

  const handleRestock = () => {
    const amount = parseInt(restockAmount, 10);
    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid positive number for quantity.');
      return;
    }

    const updated = medicines.map((med) => {
      if (med.id === selectedMedicine.id) {
        const newQuantity = med.quantity + amount;
        let newStatus = 'In Stock';
        if (newQuantity === 0) newStatus = 'Out of Stock';
        else if (newQuantity < 30) newStatus = 'Low Stock';
        else newStatus = 'In Stock';

        return { ...med, quantity: newQuantity, status: newStatus };
      }
      return med;
    });

    setMedicines(updated);
    setRestockModalVisible(false);
    setSelectedMedicine(null);
    setRestockAmount('');
  };

  const handleAddMedicine = () => {
    if (!newMedicine.name || newMedicine.quantity === '') {
      alert('Please fill all fields');
      return;
    }
    const qty = parseInt(newMedicine.quantity, 10);
    if (isNaN(qty) || qty < 0) {
      alert('Quantity must be a non-negative number');
      return;
    }

    const newMed = {
      id: medicines.length ? medicines[medicines.length - 1].id + 1 : 1,
      name: newMedicine.name,
      quantity: qty,
      status: newMedicine.status,
    };

    setMedicines([newMed, ...medicines]);

    setNewMedicine({
      name: '',
      quantity: '',
      status: statuses[0],
    });
    setShowAddModal(false);
  };

  return (
    <div className="pharmacy-inventory-wrapper">
      <Sidebar />
      <div className="pharmacy-inventory-main">
        <TopBar />

        {/* Search and Add New Medicine OUTSIDE the container */}
        <div
          style={{
            maxWidth: 1000,
            margin: '20px auto',
            display: 'flex',
            gap: 10,
            alignItems: 'center',
          }}
        >
          <input
            type="text"
            placeholder="Search by medicine name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
            style={{
              flexGrow: 1,
              padding: 8,
              fontSize: 16,
              borderRadius: 4,
              border: '1px solid #ccc',
            }}
          />
          <button
            onClick={() => setShowAddModal(true)}
            className="add-medicine-btn"
            style={{
              display: 'flex',
              alignItems: 'center',
              backgroundColor: '#1E3A8A',
              color: 'white',
              border: 'none',
              padding: '8px 14px',
              fontSize: 16,
              cursor: 'pointer',
              borderRadius: 4,
              gap: 6,
            }}
          >
            <Plus size={16} />
            Add New Medicine
          </button>
        </div>

        {/* Inventory container now only contains the table and modals */}
        <div
          className="pharmacy-inventory-container"
          style={{ maxWidth: 1000, margin: '0 auto' }}
        >
          {/* Inventory Table */}
          <table
            className="inventory-table"
            style={{ width: '100%', borderCollapse: 'collapse' }}
          >
            <thead>
              <tr style={{ borderBottom: '2px solid #ccc' }}>
                <th style={{ padding: '10px' }}>ID</th>
                <th style={{ padding: '10px' }}>Name</th>
                <th style={{ padding: '10px' }}>Quantity</th>
                <th style={{ padding: '10px' }}>Status</th>
                <th style={{ padding: '10px' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMedicines.length === 0 ? (
                <tr>
                  <td colSpan="5" style={{ textAlign: 'center', padding: 20 }}>
                    No medicines found.
                  </td>
                </tr>
              ) : (
                filteredMedicines.map((med) => (
                  <tr key={med.id} style={{ borderBottom: '1px solid #eee' }}>
                    <td style={{ padding: '10px' }}>{med.id}</td>
                    <td style={{ padding: '10px' }}>{med.name}</td>
                    <td style={{ padding: '10px' }}>{med.quantity}</td>
                    <td style={{ padding: '10px' }}>
                      <select
                        value={med.status}
                        onChange={(e) =>
                          handleStatusChange(med.id, e.target.value)
                        }
                        style={{ padding: 6, borderRadius: 4 }}
                      >
                        {statuses.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td style={{ padding: '10px' }}>
                      <button
                        onClick={() => openRestockModal(med)}
                        style={{
                          backgroundColor: '#319f43',
                          color: 'white',
                          border: 'none',
                          padding: '6px 12px',
                          borderRadius: 4,
                          cursor: 'pointer',
                        }}
                      >
                        Restock
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Restock Modal */}
        {restockModalVisible && selectedMedicine && (
          <div
            className="modal-overlay"
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0,0,0,0.5)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 9999,
            }}
          >
            <div
              className="modal-content"
              style={{
                backgroundColor: 'white',
                padding: 20,
                borderRadius: 8,
                width: 400,
              }}
            >
              <h3>Restock: {selectedMedicine.name}</h3>
              <label>
                Quantity to add:
                <input
                  type="number"
                  min="1"
                  value={restockAmount}
                  onChange={(e) => setRestockAmount(e.target.value)}
                  style={{ width: '100%', padding: 8, marginTop: 8, marginBottom: 16 }}
                  autoFocus
                />
              </label>
              <div style={{ textAlign: 'right' }}>
                <button
                  onClick={() => setRestockModalVisible(false)}
                  style={{ marginRight: 10 }}
                >
                  Cancel
                </button>
                <button onClick={handleRestock} className="restock-btn">
  Restock
</button>


              </div>
            </div>
          </div>
        )}

        {/* Add New Medicine Modal */}
        {showAddModal && (
          <div
            className="modal-overlay"
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0,0,0,0.5)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 9999,
            }}
          >
            <div
              className="modal-content"
              style={{
                backgroundColor: 'white',
                padding: 20,
                borderRadius: 8,
                width: 400,
              }}
            >
              <h3>Add New Medicine</h3>
              <label>
                Name:
                <input
                  type="text"
                  value={newMedicine.name}
                  onChange={(e) =>
                    setNewMedicine({ ...newMedicine, name: e.target.value })
                  }
                  style={{ width: '100%', padding: 8, marginTop: 8, marginBottom: 12 }}
                  autoFocus
                />
              </label>
              <label>
                Quantity:
                <input
                  type="number"
                  min="0"
                  value={newMedicine.quantity}
                  onChange={(e) =>
                    setNewMedicine({ ...newMedicine, quantity: e.target.value })
                  }
                  style={{ width: '100%', padding: 8, marginTop: 8, marginBottom: 12 }}
                />
              </label>
              <label>
                Status:
                <select
                  value={newMedicine.status}
                  onChange={(e) =>
                    setNewMedicine({ ...newMedicine, status: e.target.value })
                  }
                  style={{ width: '100%', padding: 8, marginTop: 8, marginBottom: 12 }}
                >
                  {statuses.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>
              </label>
              <div style={{ textAlign: 'right', marginTop: 16 }}>
                <button
                  onClick={() => setShowAddModal(false)}
                  style={{ marginRight: 10 }}
                >
                  Cancel
                </button>
                <button onClick={handleAddMedicine}>Add Medicine</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PharmacyInventory;
