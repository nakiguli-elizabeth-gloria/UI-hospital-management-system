// src/pages/Pharmacist/PharmacistBilling.jsx

import React, { useState, useRef } from 'react';
import '../../assets/css/Pharmacist/PharmacistBilling.css';
import PharmacistSidebar from '../../components/PharmacistSidebar';
import PharmacistTopBar from '../../components/PharmacistTopbar';

const PharmacistBilling = () => {
  const [patientName, setPatientName] = useState('');
  const [items, setItems] = useState([]);
  const [medicine, setMedicine] = useState({ name: '', quantity: '', price: '' });
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [insuranceProvider, setInsuranceProvider] = useState('');
  const [cardNumber, setCardNumber] = useState('');

  const printRef = useRef();

  const handleAddItem = () => {
    if (medicine.name && medicine.quantity && medicine.price) {
      setItems([
        ...items,
        {
          name: medicine.name,
          quantity: parseInt(medicine.quantity),
          price: parseFloat(medicine.price),
        },
      ]);
      setMedicine({ name: '', quantity: '', price: '' });
    } else {
      alert('Please fill in all medicine fields.');
    }
  };

  const totalAmount = items.reduce(
    (acc, item) => acc + item.quantity * item.price,
    0
  );

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const newWindow = window.open('', '', 'width=800,height=600');
    newWindow.document.write(`
      <html>
        <head>
          <title>Print Bill</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 8px; text-align: left; }
            th { background-color: #f0f0f0; }
            h2, h3, p { margin: 0 0 10px 0; }
          </style>
        </head>
        <body>
          <h2>Pharmacy Bill</h2>
          <p><strong>Patient Name:</strong> ${patientName || 'N/A'}</p>
          <p><strong>Payment Method:</strong> ${paymentMethod}</p>
          ${
            paymentMethod === 'insurance'
              ? `<p><strong>Insurance Provider:</strong> ${insuranceProvider}</p>`
              : paymentMethod === 'card'
              ? `<p><strong>Card Number:</strong> ${cardNumber}</p>`
              : ''
          }
          ${printContents}
        </body>
      </html>
    `);
    newWindow.document.close();
    newWindow.focus();
    newWindow.print();
    newWindow.close();
  };

  return (
    <div className="pharmacist-billing-page">
      <PharmacistSidebar />
      <div className="main-content">
        <PharmacistTopBar title="Billing" />
        <div className="billing-content-wrapper">
          <div className="billing-container">
            <div className="form-group">
              <label>Patient Name</label>
              <input
                type="text"
                placeholder="Enter patient name"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
              />
            </div>

            {/* Medicine Input Section */}
            <div className="medicine-section">
              <h3>Add Medicine</h3>
              <div className="medicine-inputs">
                <input
                  type="text"
                  placeholder="Medicine Name"
                  value={medicine.name}
                  onChange={(e) => setMedicine({ ...medicine, name: e.target.value })}
                />
                <input
                  type="number"
                  placeholder="Quantity"
                  value={medicine.quantity}
                  onChange={(e) => setMedicine({ ...medicine, quantity: e.target.value })}
                />
                <input
                  type="number"
                  placeholder="Price"
                  value={medicine.price}
                  onChange={(e) => setMedicine({ ...medicine, price: e.target.value })}
                  step="0.01"
                />
                <button onClick={handleAddItem} className="add-btn">Add</button>
              </div>
            </div>

            <div className="form-group">
              <label>Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
              >
                <option value="cash">Cash</option>
                <option value="card">Card</option>
                <option value="insurance">Insurance</option>
              </select>
            </div>

            {paymentMethod === 'card' && (
              <div className="form-group">
                <label>Card Number</label>
                <input
                  type="text"
                  placeholder="Enter card number"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                />
              </div>
            )}

            {paymentMethod === 'insurance' && (
              <div className="form-group">
                <label>Insurance Provider</label>
                <input
                  type="text"
                  placeholder="Enter insurance provider"
                  value={insuranceProvider}
                  onChange={(e) => setInsuranceProvider(e.target.value)}
                />
              </div>
            )}

            {/* Bill Summary Table */}
            <div className="bill-summary" ref={printRef}>
              <h3>Bill Summary</h3>
              <table>
                <thead>
                  <tr>
                    <th>Medicine</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, idx) => (
                    <tr key={idx}>
                      <td>{item.name}</td>
                      <td>{item.quantity}</td>
                      <td>${item.price.toFixed(2)}</td>
                      <td>${(item.quantity * item.price).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="total">
                <strong>Total Amount:</strong> ${totalAmount.toFixed(2)}
              </div>
            </div>

            <button onClick={handlePrint} className="print-btn">
              Print Bill
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PharmacistBilling;
