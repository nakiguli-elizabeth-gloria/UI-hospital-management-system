// src/pages/Receptionist/ReceptionistNotificationsPage.jsx

import React from 'react';
import ReceptionistSidebar from '../../components/ReceptionistSidebar';
import ReceptionistTopbar from '../../components/ReceptionistTopbar';
import '../../assets/css/Receptionist/ReceptionistNotificationsPage.css';

const notifications = [
  {
    id: 1,
    title: 'New Patient Registration',
    message: 'Patient Mary Johnson has been registered successfully.',
    date: '2025-07-17',
    read: false,
  },
  {
    id: 2,
    title: 'Appointment Cancelled',
    message: 'Appointment for patient Robert Lee on 2025-07-18 at 2:00 PM was cancelled.',
    date: '2025-07-16',
    read: true,
  },
  {
    id: 3,
    title: 'Message from Doctor',
    message: 'Dr. Smith: Please prepare patient files for tomorrow’s appointments.',
    date: '2025-07-15',
    read: false,
  },
];

const ReceptionistNotificationsPage = () => {
  return (
    <div className="receptionist-notifications-page">
      <ReceptionistSidebar />
      <div className="main-content">
        <ReceptionistTopbar />
        <div className="notifications-container">
          <h2 className="notifications-title">Notifications</h2>
          {notifications.length === 0 ? (
            <p className="no-notifications">No new notifications.</p>
          ) : (
            // Remove extra wrapping div here
            notifications.map(({ id, title, message, date, read }) => (
              <div
                key={id}
                className={`notification-card ${read ? 'read' : 'unread'}`}
              >
                <div className="notification-header">
                  <h3>{title}</h3>
                  <span className="notification-date">{date}</span>
                </div>
                <p className="notification-message">{message}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default ReceptionistNotificationsPage;
