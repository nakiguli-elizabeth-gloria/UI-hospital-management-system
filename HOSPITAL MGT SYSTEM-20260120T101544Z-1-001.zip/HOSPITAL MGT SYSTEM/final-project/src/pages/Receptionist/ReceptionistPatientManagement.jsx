import React, { useState } from 'react';
import Sidebar from '../../components/ReceptionistSidebar';
import TopBar from '../../components/ReceptionistTopbar';
import '../../assets/css/Receptionist/ReceptionistPatientManagement.css';

const doctors = [
  { id: 1, name: 'Dr. Adams', specialty: 'Cardiology', available: true },
  { id: 2, name: 'Dr. Baker', specialty: 'Dermatology', available: false },
  { id: 3, name: 'Dr. Clark', specialty: 'Pediatrics', available: true },
];

const initialPatients = [
  {
    id: 1,
    name: 'John Doe',
    age: 45,
    gender: 'Male',
    status: 'Admitted', // changed from admitted boolean to status string
    admissionDate: '2025-07-12',
    dischargeDate: null,
    email: 'john@example.com',
  },
  {
    id: 2,
    name: 'Jane Smith',
    age: 30,
    gender: 'Female',
    status: 'Discharged',
    admissionDate: '2025-06-25',
    dischargeDate: '2025-07-05',
    email: 'jane@example.com',
  },
];

const statusColors = {
  Admitted: '#319F43', // green
  Discharged: '#d14343', // red
  Visiting: '#f5a623', // orange
};

const ReceptionistPatientManagement = () => {
  const [patients, setPatients] = useState(initialPatients);
  const [searchTerm, setSearchTerm] = useState('');
  const [newPatient, setNewPatient] = useState({
    name: '',
    age: '',
    gender: '',
    phone: '',
    email: '',
    address: '',
    password: '',
    confirmPassword: '',
  });
  const [editingPatient, setEditingPatient] = useState(null);
  const [appointmentPatient, setAppointmentPatient] = useState(null);
  const [appointmentData, setAppointmentData] = useState({ doctorId: '', date: '', time: '' });
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  const handleNewPatientChange = (e) => {
    const { name, value } = e.target;
    setNewPatient((prev) => ({ ...prev, [name]: value }));
  };

  const handleRegisterPatient = (e) => {
    e.preventDefault();
    const { name, age, gender, phone, email, address, password, confirmPassword } = newPatient;

    if (!name || !age || !gender || !phone || !email || !address || !password || !confirmPassword) {
      alert('Please fill all patient details');
      return;
    }

    const emailRegex = /^\S+@\S+\.\S+$/;
    if (!emailRegex.test(email)) {
      alert('Please enter a valid email address');
      return;
    }

    if (password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    const newId = patients.length ? Math.max(...patients.map((p) => p.id)) + 1 : 1;
    const newPatientObj = {
      id: newId,
      name,
      age,
      gender,
      phone,
      email,
      address,
      status: 'Visiting', // default to Visiting
      admissionDate: null,
      dischargeDate: null,
    };

    // Add new patient to the TOP of the list
    setPatients((prev) => [newPatientObj, ...prev]);

    setNewPatient({
      name: '',
      age: '',
      gender: '',
      phone: '',
      email: '',
      address: '',
      password: '',
      confirmPassword: '',
    });
    setShowRegisterModal(false);
    alert('Patient registered successfully');
  };

  const handleEditPatientChange = (e) => {
    const { name, value } = e.target;
    setEditingPatient((prev) => ({ ...prev, [name]: value }));
  };

  const saveEditedPatient = (e) => {
    e.preventDefault();
    setPatients((prev) =>
      prev.map((p) => (p.id === editingPatient.id ? editingPatient : p))
    );
    setEditingPatient(null);
    alert('Patient details updated');
  };

  const handleAppointmentChange = (e) => {
    const { name, value } = e.target;
    setAppointmentData((prev) => ({ ...prev, [name]: value }));
  };

  const bookAppointment = (e) => {
    e.preventDefault();
    if (!appointmentData.doctorId || !appointmentData.date || !appointmentData.time) {
      alert('Fill all appointment details');
      return;
    }
    alert(
      `Appointment booked for ${appointmentPatient.name} with Doctor ID ${appointmentData.doctorId} on ${appointmentData.date} at ${appointmentData.time}`
    );
    setAppointmentPatient(null);
    setAppointmentData({ doctorId: '', date: '', time: '' });
  };

  const handleStatusChange = (patientId, newStatus) => {
    setPatients((prev) =>
      prev.map((p) =>
        p.id === patientId
          ? {
              ...p,
              status: newStatus,
              admissionDate: newStatus === 'Admitted' && !p.admissionDate ? new Date().toISOString().split('T')[0] : p.admissionDate,
              dischargeDate: newStatus === 'Discharged' ? new Date().toISOString().split('T')[0] : null,
            }
          : p
      )
    );
  };

  // Filter patients based on searchTerm (name or email)
  const filteredPatients = patients.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.email && p.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="receptionist-patient-management-page">
      <Sidebar />
      <div className="main-content">
        <TopBar />
        <div className="management-content">
          {/* Use CSS class for container */}
          <div className="search-register-container">
            <input
              type="text"
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="search-input"
            />
            <button
  className="btn register-btn"
  onClick={() => setShowRegisterModal(true)}
>
  Register New Patient
</button>

          </div>

          <section className="section existing-patients">
            <table className="user-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Gender</th>
                  <th>Status</th>
                  <th>Admission</th>
                  <th>Discharge</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredPatients.length === 0 ? (
                  <tr>
                    <td colSpan="6" style={{ textAlign: 'center', padding: 20 }}>
                      No patients found.
                    </td>
                  </tr>
                ) : (
                  filteredPatients.map((p) => (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td>{p.gender}</td>
                      <td>
                        <select
                          value={p.status}
                          onChange={(e) => handleStatusChange(p.id, e.target.value)}
                          style={{
                            color: statusColors[p.status] || '#000',
                            fontWeight: '600',
                            border: 'none',
                            background: 'transparent',
                            cursor: 'pointer',
                          }}
                        >
                          <option value="Admitted">Admitted</option>
                          <option value="Discharged">Discharged</option>
                          <option value="Visiting">Visiting</option>
                        </select>
                      </td>
                      <td>{p.admissionDate || '-'}</td>
                      <td>{p.dischargeDate || '-'}</td>
                      <td>
                        <button
                          className="edit-btn"
                          onClick={() => setEditingPatient(p)}
                          style={{ marginRight: 8 }}
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </section>

          {/* Register Modal */}
          {showRegisterModal && (
            <div className="modal-overlay" onClick={() => setShowRegisterModal(false)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <button className="modal-close-btn" onClick={() => setShowRegisterModal(false)}>
                  ×
                </button>
                <h3>Register New Patient</h3>
                <form onSubmit={handleRegisterPatient} className="form">
                  <input
                    type="text"
                    name="name"
                    placeholder="Full Name"
                    value={newPatient.name}
                    onChange={handleNewPatientChange}
                    required
                  />
                  <input
                    type="number"
                    name="age"
                    placeholder="Age"
                    value={newPatient.age}
                    onChange={handleNewPatientChange}
                    required
                    min={0}
                  />
                  <select
                    name="gender"
                    value={newPatient.gender}
                    onChange={handleNewPatientChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                  <input
                    type="tel"
                    name="phone"
                    placeholder="Phone Number"
                    value={newPatient.phone}
                    onChange={handleNewPatientChange}
                    required
                  />
                  <input
                    type="email"
                    name="email"
                    placeholder="Email Address"
                    value={newPatient.email}
                    onChange={handleNewPatientChange}
                    required
                  />
                  <textarea
                    name="address"
                    placeholder="Address"
                    value={newPatient.address}
                    onChange={handleNewPatientChange}
                    required
                    rows={3}
                  />
                  <input
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={newPatient.password}
                    onChange={handleNewPatientChange}
                    required
                  />
                  <input
                    type="password"
                    name="confirmPassword"
                    placeholder="Confirm Password"
                    value={newPatient.confirmPassword}
                    onChange={handleNewPatientChange}
                    required
                  />
                  <div style={{ marginTop: 16, textAlign: 'right' }}>
                    <button
                      type="button"
                      className="btn cancel"
                      onClick={() => setShowRegisterModal(false)}
                      style={{ marginRight: 10 }}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="btn">
                      Register
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Appointment Modal */}
          {appointmentPatient && (
            <div className="modal-overlay" onClick={() => setAppointmentPatient(null)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <button className="modal-close-btn" onClick={() => setAppointmentPatient(null)}>
                  ×
                </button>
                <h3>Book Appointment for {appointmentPatient.name}</h3>
                <form onSubmit={bookAppointment} className="form">
                  <select
                    name="doctorId"
                    value={appointmentData.doctorId}
                    onChange={handleAppointmentChange}
                    required
                  >
                    <option value="">Select Doctor</option>
                    {doctors
                      .filter((d) => d.available)
                      .map((doc) => (
                        <option key={doc.id} value={doc.id}>
                          {doc.name} — {doc.specialty}
                        </option>
                      ))}
                  </select>
                  <input
                    type="date"
                    name="date"
                    value={appointmentData.date}
                    onChange={handleAppointmentChange}
                    required
                  />
                  <input
                    type="time"
                    name="time"
                    value={appointmentData.time}
                    onChange={handleAppointmentChange}
                    required
                  />
                  <div style={{ marginTop: 16, textAlign: 'right' }}>
                    <button
                      type="button"
                      className="btn cancel"
                      onClick={() => setAppointmentPatient(null)}
                      style={{ marginRight: 10 }}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="btn">
                      Confirm
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Edit Modal */}
          {editingPatient && (
            <div className="modal-overlay" onClick={() => setEditingPatient(null)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <button className="modal-close-btn" onClick={() => setEditingPatient(null)}>
                  ×
                </button>
                <h3>Edit Patient: {editingPatient.name}</h3>
                <form onSubmit={saveEditedPatient} className="form">
                  <input
                    type="text"
                    name="name"
                    value={editingPatient.name}
                    onChange={handleEditPatientChange}
                    required
                  />
                  <input
                    type="number"
                    name="age"
                    value={editingPatient.age}
                    onChange={handleEditPatientChange}
                    required
                  />
                  <select
                    name="gender"
                    value={editingPatient.gender}
                    onChange={handleEditPatientChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                  <div style={{ marginTop: 16, textAlign: 'right' }}>
                    <button
                      type="button"
                      className="btn cancel"
                      onClick={() => setEditingPatient(null)}
                      style={{ marginRight: 10 }}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="btn">
                      Save
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReceptionistPatientManagement;
