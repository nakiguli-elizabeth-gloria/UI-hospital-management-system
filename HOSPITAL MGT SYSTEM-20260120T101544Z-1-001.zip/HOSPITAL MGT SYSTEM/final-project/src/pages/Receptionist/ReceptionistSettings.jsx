import React, { useState } from 'react';
import Sidebar from '../../components/ReceptionistSidebar';
import TopBar from '../../components/ReceptionistTopbar';
import '../../assets/css/Receptionist/ReceptionistSettings.css';

const ReceptionistSettings = () => {
  const [fullName, setFullName] = useState('Jane Doe');
  const [email, setEmail] = useState('janedoe@example.com');
  const [phone, setPhone] = useState('0700123456');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleProfileUpdate = () => {
    // Add validations if needed
    alert('Profile updated successfully!');
  };

  const handlePasswordChange = () => {
    if (newPassword !== confirmPassword) {
      alert('New password and confirmation do not match!');
    } else {
      alert('Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  return (
    <div className="receptionist-settings-page">
      <Sidebar />
      <div className="main-content">
        <TopBar />
        <div className="settings-content">
          {/* Profile Update Section */}
          <div className="settings-section">
            <h3 className="section-title">Receptionist Profile</h3>
            <div className="input-field">
              <label>Full Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <button className="update-button" onClick={handleProfileUpdate}>
              Update Profile
            </button>
          </div>

          {/* Password Change Section */}
          <div className="settings-section">
            <h3 className="section-title">Change Password</h3>
            <div className="input-field">
              <label>Current Password</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>New Password</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
            <div className="input-field">
              <label>Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>
            <button className="update-button" onClick={handlePasswordChange}>
              Change Password
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReceptionistSettings;
