import React, { useState } from 'react';
import '../../assets/css/Receptionist/ReceptionistDashboard.css';
import Sidebar from '../../components/ReceptionistSidebar';
import TopBar from '../../components/ReceptionistTopbar';
import { Users, CreditCard, CalendarCheck, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';

const initialAppointments = [
  { id: 1, patient: 'John Doe', date: '2025-07-15', time: '10:00 AM', doctor: 'Dr. Adams', reason: 'Checkup', status: 'Confirmed' },
  { id: 2, patient: 'Jane Smith', date: '2025-07-17', time: '2:30 PM', doctor: 'Dr. Baker', reason: 'Consultation', status: 'Pending' },
  { id: 3, patient: 'Mark Lee', date: '2025-07-17', time: '4:00 PM', doctor: 'Dr. Clark', reason: 'Follow-up', status: 'Confirmed' },
  { id: 4, patient: 'Alice Green', date: '2025-07-20', time: '9:00 AM', doctor: 'Dr. Adams', reason: 'Blood Test', status: 'Confirmed' },
];

function getMonthDays(year, month) {
  return Array.from({ length: new Date(year, month + 1, 0).getDate() }, (_, i) => i + 1);
}

const ReceptionistDashboard = () => {
  const [appointments, setAppointments] = useState(initialAppointments);
  const [selectedDate, setSelectedDate] = useState(null);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [showModal, setShowModal] = useState(false);

  const [newAppt, setNewAppt] = useState({
    patient: '',
    time: '',
    doctor: '',
    reason: '',
    status: 'Pending',
  });

  const appointmentsByDate = appointments.reduce((acc, appt) => {
    if (!acc[appt.date]) acc[appt.date] = [];
    acc[appt.date].push(appt);
    return acc;
  }, {});

  const daysInMonth = getMonthDays(currentYear, currentMonth);

  const handleDayClick = (day) => {
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    setSelectedDate(dateStr);
    setShowModal(true);
    setNewAppt({
      patient: '',
      time: '',
      doctor: '',
      reason: '',
      status: 'Pending',
    });
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedDate(null);
  };

  const goToPreviousMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
    setSelectedDate(null);
    setShowModal(false);
  };

  const goToNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
    setSelectedDate(null);
    setShowModal(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewAppt(prev => ({ ...prev, [name]: value }));
  };

  const handleAddAppointment = (e) => {
    e.preventDefault();
    if (!newAppt.patient || !newAppt.time || !newAppt.doctor || !newAppt.reason) {
      alert('Please fill all fields.');
      return;
    }

    const newAppointment = {
      id: appointments.length + 1,
      date: selectedDate,
      ...newAppt,
    };

    setAppointments(prev => [...prev, newAppointment]);
    setNewAppt({
      patient: '',
      time: '',
      doctor: '',
      reason: '',
      status: 'Pending',
    });
  };

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const firstWeekday = new Date(currentYear, currentMonth, 1).getDay();

  return (
    <div className="receptionist-dashboard">
      <Sidebar />
      <div className="main-content">
        <TopBar />
        <div className="dashboard-wrapper">
          <div className="left-panel">
            <div className="card-grid">
              <Link to="/receptionist-patient-management" className="dashboard-card-link">
                <div className="dashboard-card">
                  <Users className="dashboard-icon" />
                  <h3>Manage Patients</h3>
                  <p>New patient registration and records.</p>
                </div>
              </Link>
              <Link to="/receptionist-billing" className="dashboard-card-link">
                <div className="dashboard-card">
                  <CreditCard className="dashboard-icon" />
                  <h3>Billing</h3>
                  <p>Track and manage billing details.</p>
                </div>
              </Link>
              <Link to="/receptionist-settings" className="dashboard-card-link">
                <div className="dashboard-card">
                  <Settings className="dashboard-icon" />
                  <h3>Settings</h3>
                  <p>Schedule and update patient appointments.</p>
                </div>
              </Link>
            </div>

            <div className="calendar-section">
              <div className="calendar-header">
                <button className="calendar-nav-btn" onClick={goToPreviousMonth}>&lt;</button>
                <h3>{new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long', year: 'numeric' })}</h3>
                <button className="calendar-nav-btn" onClick={goToNextMonth}>&gt;</button>
              </div>

              <div className="calendar-grid">
                {dayNames.map(day => (
                  <div key={day} className="calendar-day-name">{day}</div>
                ))}
                {[...Array(firstWeekday)].map((_, i) => (
                  <div key={'empty-' + i} className="calendar-day empty"></div>
                ))}
                {daysInMonth.map(day => {
                  const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                  const hasAppointment = !!appointmentsByDate[dateStr];
                  const isSelected = selectedDate === dateStr;

                  return (
                    <div
                      key={day}
                      className={`calendar-day ${hasAppointment ? 'has-appointment' : ''} ${isSelected ? 'selected' : ''}`}
                      onClick={() => handleDayClick(day)}
                      title={hasAppointment ? `${appointmentsByDate[dateStr].length} appointment(s)` : ''}
                    >
                      {day}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {showModal && selectedDate && (
            <div className="modal-overlay" onClick={closeModal}>
              <div className="modal-content" onClick={e => e.stopPropagation()}>
                <button className="modal-close-btn" onClick={closeModal}>×</button>
                <h3>Appointments on {selectedDate}</h3>

                {appointmentsByDate[selectedDate]?.length > 0 ? (
                  <div className="appointment-cards-container">
                    {appointmentsByDate[selectedDate].map(appt => (
                      <div key={appt.id} className="appointment-card">
                        <p><strong>Patient:</strong> {appt.patient}</p>
                        <p><strong>Time:</strong> {appt.time}</p>
                        <p><strong>Doctor:</strong> {appt.doctor}</p>
                        <p><strong>Reason:</strong> {appt.reason}</p>
                        <p><strong>Status:</strong> {appt.status}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p>No appointments scheduled for this day.</p>
                )}

                <hr style={{ margin: '20px 0' }} />
                <h4>Add New Appointment</h4>
                <form onSubmit={handleAddAppointment} className="appointment-form">
                  <div className="form-group">
                    <label>Patient Name:</label>
                    <input type="text" name="patient" value={newAppt.patient} onChange={handleInputChange} required />
                  </div>

                  <div className="form-group">
                    <label>Time (e.g. 10:30 AM):</label>
                    <input type="text" name="time" value={newAppt.time} onChange={handleInputChange} required />
                  </div>

                  <div className="form-group">
                    <label>Doctor:</label>
                    <input type="text" name="doctor" value={newAppt.doctor} onChange={handleInputChange} required />
                  </div>

                  <div className="form-group">
                    <label>Reason:</label>
                    <input type="text" name="reason" value={newAppt.reason} onChange={handleInputChange} required />
                  </div>

                  <div className="form-group">
                    <label>Status:</label>
                    <select name="status" value={newAppt.status} onChange={handleInputChange}>
                      <option value="Pending">Pending</option>
                      <option value="Confirmed">Confirmed</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </div>

                  <button type="submit" className="submit-btn">Add Appointment</button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReceptionistDashboard;
