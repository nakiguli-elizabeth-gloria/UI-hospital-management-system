import React, { useState } from 'react';
import Sidebar from '../../components/ReceptionistSidebar';
import TopBar from '../../components/ReceptionistTopbar';
import '../../assets/css/Receptionist/ReceptionistBilling.css';

const initialBills = [
  { id: 1, patient: 'John Doe', date: '2025-07-10', amount: 150, status: 'Paid' },
  { id: 2, patient: 'Jane Smith', date: '2025-07-12', amount: 200, status: 'Pending' },
  { id: 3, patient: 'Mark Lee', date: '2025-07-14', amount: 300, status: 'Paid' },
  // ... (rest of your data)
];

const ReceptionistBilling = () => {
  const [bills, setBills] = useState(initialBills);
  const [newBill, setNewBill] = useState({
    patient: '',
    date: '',
    amount: '',
    status: 'Pending',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewBill(prev => ({ ...prev, [name]: value }));
  };

  const handleAddBill = (e) => {
    e.preventDefault();
    if (!newBill.patient || !newBill.date || !newBill.amount) {
      alert('Please fill all fields');
      return;
    }
    const billToAdd = {
      ...newBill,
      id: bills.length + 1,
      amount: Number(newBill.amount),
    };
    setBills(prev => [billToAdd, ...prev]);
    setNewBill({ patient: '', date: '', amount: '', status: 'Pending' });
  };

  const handleStatusChange = (id, newStatus) => {
    setBills(prevBills =>
      prevBills.map(bill =>
        bill.id === id ? { ...bill, status: newStatus } : bill
      )
    );
  };

  return (
    <div className="receptionist-billing-page">
      <Sidebar />
      <div className="main-content">
        <TopBar />
        <div className="billing-content">
          <form className="billing-form" onSubmit={handleAddBill}>
            <input
              type="text"
              name="patient"
              placeholder="Patient Name"
              value={newBill.patient}
              onChange={handleInputChange}
              required
            />
            <input
              type="date"
              name="date"
              value={newBill.date}
              onChange={handleInputChange}
              required
            />
            <input
              type="number"
              name="amount"
              placeholder="Amount"
              value={newBill.amount}
              onChange={handleInputChange}
              min="0"
              step="0.01"
              required
            />
            <select
              name="status"
              value={newBill.status}
              onChange={handleInputChange}
            >
              <option value="Pending">Pending</option>
              <option value="Paid">Paid</option>
            </select>
            <button type="submit" className="add-bill-btn">Add Bill</button>
          </form>

          <div className="billing-table-wrapper">
            <table className="billing-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Date</th>
                  <th>Amount ($)</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {bills.map(({ id, patient, date, amount, status }) => (
                  <tr key={id}>
                    <td>{patient}</td>
                    <td>{date}</td>
                    <td>{amount.toFixed(2)}</td>
                    <td>
                      {status === 'Pending' ? (
                        <select
                          className={status.toLowerCase()}
                          value={status}
                          onChange={(e) => handleStatusChange(id, e.target.value)}
                        >
                          <option value="Pending">Pending</option>
                          <option value="Paid">Paid</option>
                        </select>
                      ) : (
                        <span className={status.toLowerCase()}>{status}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReceptionistBilling;
