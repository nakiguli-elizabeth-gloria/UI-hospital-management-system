import React from 'react';
import { NavLink } from 'react-router-dom';
import '../assets/css/Receptionist/ReceptionistSidebar.css';
import logo from '../assets/images/logo.png';

// Import icons from lucide-react
import {
  LayoutDashboard,
  Users,
  CreditCard,
  Settings,
  CalendarCheck2,
  MessageCircle
} from 'lucide-react';

const ReceptionistSidebar = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-logo-container">
          <img src={logo} alt="CityCare Logo" className="sidebar-logo" />
        </div>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/receptionist-dashboard" activeClassName="active">
          <LayoutDashboard className="sidebar-icon" />
          <span>Receptionist Dashboard</span>
        </NavLink>

        <NavLink to="/receptionist-patient-management" activeClassName="active">
          <Users className="sidebar-icon" />
          <span>Manage Patients</span>
        </NavLink>

        {/* Uncomment if implementing appointment page */}
        {/* 
        <NavLink to="/receptionist-appointments" activeClassName="active">
          <CalendarCheck2 className="sidebar-icon" />
          <span>Manage Appointments</span>
        </NavLink> 
        */}

        <NavLink to="/receptionist-billing" activeClassName="active">
          <CreditCard className="sidebar-icon" />
          <span>Billing</span>
        </NavLink>

        <NavLink to="/receptionist-settings" activeClassName="active">
          <Settings className="sidebar-icon" />
          <span>Settings</span>
        </NavLink>

        {/* Uncomment if implementing messaging */}
        {/* 
        <NavLink to="/receptionist-messages" activeClassName="active">
          <MessageCircle className="sidebar-icon" />
          <span>Messages</span>
        </NavLink> 
        */}
      </nav>
    </div>
  );
};

export default ReceptionistSidebar;
