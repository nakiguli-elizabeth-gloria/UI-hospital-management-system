import React from 'react';
import { NavLink } from 'react-router-dom';
import '../assets/css/Admin/AdminSidebar.css';
import logo from '../assets/images/logo.png';

// Icons from lucide-react
import { LayoutDashboard, Users, FolderKanban, CalendarCheck2, CreditCard, Settings } from 'lucide-react';

const AdminSidebar = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-logo-container">
          <img src={logo} alt="CityCare Logo" className="sidebar-logo" />
        </div>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/admin-dashboard" activeClassName="active">
          <LayoutDashboard className="sidebar-icon" />
          <span>Admin Dashboard</span>
        </NavLink>

        <NavLink to="/users" activeClassName="active">
          <Users className="sidebar-icon" />
          <span>Manage Users</span>
        </NavLink>

        <NavLink to="/resources" activeClassName="active">
          <FolderKanban className="sidebar-icon" />
          <span>Manage Resources</span>
        </NavLink>

        <NavLink to="/appointments" activeClassName="active">
          <CalendarCheck2 className="sidebar-icon" />
          <span>Manage Appointments</span>
        </NavLink>

        <NavLink to="/billing" activeClassName="active">
          <CreditCard className="sidebar-icon" />
          <span>Billing</span>
        </NavLink>

        <NavLink to="/settings" activeClassName="active">
          <Settings className="sidebar-icon" />
          <span>Settings</span>
        </NavLink>
      </nav>
    </div>
  );
};

export default AdminSidebar;
