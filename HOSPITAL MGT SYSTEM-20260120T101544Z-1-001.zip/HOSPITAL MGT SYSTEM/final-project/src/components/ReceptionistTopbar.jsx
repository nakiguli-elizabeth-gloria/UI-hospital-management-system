import React from 'react';
import { Bell, LogOut, UserCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import '../assets/css/Receptionist/ReceptionistTopBar.css'; // Adjust CSS path

const ReceptionistTopBar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('userToken'); // Example token removal
    navigate('/login');
  };

  const handleNotifications = () => {
    navigate('/receptionist/notifications');
  };

  return (
    <div className="topbar">
      <div className="topbar-left">
        <UserCircle className="topbar-icon profile-icon" title="Profile" />
        <div className="topbar-title-group">
          <h1 className="topbar-title">Receptionist Dashboard</h1>
          <h2 className="topbar-subtitle">Arinaitwe Maisy</h2> {/* Change to actual receptionist name */}
        </div>
      </div>
      <div className="topbar-right">
        <div className="topbar-icons">
          <Bell
            className="topbar-icon"
            title="Notifications"
            onClick={handleNotifications}
          />
          <LogOut
            className="topbar-icon"
            title="Logout"
            onClick={handleLogout}
          />
        </div>
      </div>
    </div>
  );
};

export default ReceptionistTopBar;
