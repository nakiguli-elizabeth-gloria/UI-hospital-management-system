import React from 'react';
import { NavLink } from 'react-router-dom';
import '../assets/css/Doctor/DoctorSidebar.css';
import logo from '../assets/images/logo.png';

// Import icons from lucide-react
import { LayoutDashboard, Users, CalendarCheck2, CreditCard, Settings } from 'lucide-react';

const DoctorSidebar = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-logo-container">
          <img src={logo} alt="CityCare Logo" className="sidebar-logo" />
        </div>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/doctor-dashboard" activeClassName="active">
          <LayoutDashboard className="sidebar-icon" />
          <span>Doctor Dashboard</span>
        </NavLink>

        <NavLink to="/doctor-patientmanagement" activeClassName="active">
          <Users className="sidebar-icon" />
          <span>Manage Patients</span>
        </NavLink>

        <NavLink to="/doctor-appointmentpage" activeClassName="active">
          <CalendarCheck2 className="sidebar-icon" />
          <span>Manage Appointments</span>
        </NavLink>

        {/* Uncomment if needed later
        <NavLink to="/doctor-prescription" activeClassName="active">
          <Clipboard className="sidebar-icon" />
          <span>Prescriptions</span>
        </NavLink> 
        */}

        {/* <NavLink to="/doctor-billing" activeClassName="active">
          <CreditCard className="sidebar-icon" />
          <span>Billing</span>
        </NavLink> */}

        <NavLink to="/doctor-settings" activeClassName="active">
          <Settings className="sidebar-icon" />
          <span>Settings</span>
        </NavLink>
      </nav>
    </div>
  );
};

export default DoctorSidebar;
