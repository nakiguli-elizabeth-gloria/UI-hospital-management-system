import React from 'react';
import { NavLink } from 'react-router-dom';
import '../assets/css/Pharmacist/PharmacistSidebar.css';
import logo from '../assets/images/logo.png';

// Lucide icons
import {
  LayoutDashboard,
  Users,
  PackageCheck,
  CreditCard,
  Settings
} from 'lucide-react';

const PharmacistSidebar = () => {
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-logo-container">
          <img src={logo} alt="CityCare Logo" className="sidebar-logo" />
        </div>
      </div>

      <nav className="sidebar-nav">
        <NavLink to="/pharmacist-dashboard" activeClassName="active">
          <LayoutDashboard className="sidebar-icon" />
          <span>Pharmacist Dashboard</span>
        </NavLink>

        <NavLink to="/pharmacist-patientinfo" activeClassName="active">
          <Users className="sidebar-icon" />
          <span>Manage Patients</span>
        </NavLink>

        <NavLink to="/pharmacist-inventory" activeClassName="active">
          <PackageCheck className="sidebar-icon" />
          <span>Manage Inventory</span>
        </NavLink>

        {/* Uncomment when implementing prescription history
        <NavLink to="/pharmacist-prescriptionhistory" activeClassName="active">
          <FileText className="sidebar-icon" />
          <span>Prescription History</span>
        </NavLink>
        */}

        <NavLink to="/pharmacist-billing" activeClassName="active">
          <CreditCard className="sidebar-icon" />
          <span>Billing</span>
        </NavLink>

        <NavLink to="/pharmacist-settings" activeClassName="active">
          <Settings className="sidebar-icon" />
          <span>Settings</span>
        </NavLink>
      </nav>
    </div>
  );
};

export default PharmacistSidebar;
