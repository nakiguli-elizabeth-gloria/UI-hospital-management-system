import React from 'react';
import { Bell, LogOut, UserCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import '../assets/css/Doctor/DoctorTopbar.css';

const DoctorTopBar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // You can clear any user-related session/localStorage data if needed
    localStorage.removeItem('userToken');  // Example if you're using a token
    navigate('/login'); // Navigate to login page
  };

  const handleNotifications = () => {
    navigate('/doctor/notifications'); // Navigate to notifications page
  };

  return (
    <div className="topbar">
      <div className="topbar-left">
        <UserCircle className="topbar-icon profile-icon" title="Profile" />
        <div className="topbar-title-group">
          <h1 className="topbar-title">Doctor Dashboard</h1>
          <h2 className="topbar-subtitle">Dr. Tania Katunze</h2>
        </div>
      </div>
      <div className="topbar-right">
        <div className="topbar-icons">
          <Bell
            className="topbar-icon"
            title="Notifications"
            onClick={handleNotifications} // Add click handler
          />
          <LogOut
            className="topbar-icon"
            title="Logout"
            onClick={handleLogout} // Add click handler
          />
        </div>
      </div>
    </div>
  );
};

export default DoctorTopBar;
